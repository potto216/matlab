%  Start up the Field II simulation system
%
%  Version 1.1, August 13, 2007, JAJ

%  Replace the second path with the name of the directory
%  for your Field II m-files and executable

path(path, '/home/jaj/programs/field_II/M_files')

field_init
