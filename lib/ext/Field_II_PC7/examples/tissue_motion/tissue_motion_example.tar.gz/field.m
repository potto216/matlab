%  Start up the Field simulation system
%
%  Version 1.0, April 2, 1998, JAJ

path(path, '/home/jaj/programs/field_II/M_files')

field_init(0)
