function focus_version = get_focus_version()
%GET_FOCUS_VERSION Return the current version of FOCUS
    focus_version = NaN;
end

