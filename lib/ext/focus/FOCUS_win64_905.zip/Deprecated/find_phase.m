function xdcr=find_phase(xdcr,x,y,z,medium,f0,tol)
error('''find_phase'' is obsolete.  Use ''find_single_focus_phase'' instead');
