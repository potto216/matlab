/*
1. run a single iteration on both matlab and C codes, compare the output
that should show where the difference is
2. could also just look at a single point, that will certainly show something
*/

/* function input arguments:
0 - 'sar': 3 D input power (required), units are W/m^3
1 - 'stepsize' (required) distance between adjacent grid points in all
	3 dimensions, units are meters
2 - 'xbegin' (optional) if not specified, then there is no beginning boundary
	condition
3 - 'wb' blood perfusion (optional), units are kg/m^3/second
4 - 'tempboundary' temperature of the water bath (optional), has been 3deg
	temperature rise (which corresponds to 40C)
5 - 'iter' (optional) number of iterations for BHTE, defaults to 100
6 - 'mu' (optional) over-relaxation parameter, defaults to 1.6
7 - 'kappa' (optional) thermal conductivity, units are W/m/C, default is .55
8 - 'cb' (optional ) specific heat of blood, units are J/kg/C, default is 4000
9 - 'xend' (optional) if not specified, then there is no ending boundary
	condition: this last parameter is not yet implemented
*/

 /*  #define KAPPA 0.55 */
 /*  #define CB 4000.0 */
 /*  #define TOFFSET 37.0 */
 /*  #define MU 1.86 */

#include <math.h>
#include "mex.h"
#include "matrix.h"
#define H_OFFSET 1024
#define ARRAY_LENGTH 4096
#define MIN(a,b) ( ((a)>(b)) ? (b) : (a) )
#define MAX(a,b) ( ((a)>(b)) ? (a) : (b) )

/* GATEWAY FUNCTION */
 
void mexFunction(int nlhs, mxArray  *plhs[], int nrhs, const mxArray  *prhs[])
{
 /*  int j, rows, cols, ndims; */
int i;

int number_of_dims_sar;
const int  *input_dim_array_sar;
int number_of_dims_scalar;
const int  *input_dim_array_scalar;
int number_of_dims_xbegin;
const int  *input_dim_array_xbegin;
int number_of_dims_xend;
const int  *input_dim_array_xend;

double ndouble;  /*  the number of abscissas, but presently as a double precis. # */
int n;  /*  the number of abscissas, now as an integer */

double *sar;  /*  % input 3D array */
int iter;
int nz, ny, nx;
double *double_xbegin;
double *double_xend;
double mu, kappa, stepsize, wb, cb, tempboundary;

double *temprise;  /*  % output */
double *ptrtemp;  /*  % output */
double *ptrsar;  /*  % output */
int *ixptr;  /*  % output */
double *dxptr;  /*  % output */

int iz, iy, ix;
int *int_xbegin;
int *int_xend;

   if (nlhs > 1) {
        mexPrintf("BHTE requires at most ONE output argument.\n");
        mexPrintf("usage:      [TEMPRISE] = BHTE(SAR, ...);\n");
        mexErrMsgTxt("Error using ==> BHTE.");
   }

   /* Check for proper number of input arguments */
   if (nrhs < 2) {
        mexPrintf(
	   "usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
        mexErrMsgTxt("BHTE requires at least TWO input arguments.");
   }
/*
   else if (nrhs == 1) {
	iter = 2;
   }
   else if (nrhs == 0) {
   }
*/

 /*  mexPrintf("ONE\n"); */
 
   number_of_dims_sar = mxGetNumberOfDimensions(prhs[0]);
   if (number_of_dims_sar != 3) {
        mexPrintf(
	   "usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
        mexErrMsgTxt("BHTE only works at present for 3 D SAR inputs.");
   }
   input_dim_array_sar = mxGetDimensions(prhs[0]);
   if (input_dim_array_sar[0] < 3 | input_dim_array_sar[1] < 3 | 
	input_dim_array_sar[1] < 3 ) {
        mexPrintf(
	   "usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
        mexErrMsgTxt(
	   "one or more dimensions of the SAR is less than 3 slices thick");
   }
 /*  get dimensions of the input, copy these, and use them to specify the size of */
 /*  the output */
   sar = mxGetPr(prhs[0]);

   plhs[0] = mxCreateNumericArray(number_of_dims_sar, input_dim_array_sar, 
	mxDOUBLE_CLASS, mxREAL);
   temprise = mxGetPr(plhs[0]);
   nx = input_dim_array_sar[0];
   ny = input_dim_array_sar[1];
   nz = input_dim_array_sar[2];

 /*  mexPrintf("2\n"); */

   number_of_dims_scalar = mxGetNumberOfDimensions(prhs[1]);
   input_dim_array_scalar = mxGetDimensions(prhs[1]);
   if (number_of_dims_scalar == 1) {
	if (input_dim_array_scalar[0] != 1) {
 /*  fprintf(stdout, "input_dim_array_scalar[0] = %d\n", input_dim_array_scalar[0]); */
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("STEPSIZE must be a SCALAR input argument.");
	}
   }
   else {
	if (input_dim_array_scalar[0] * input_dim_array_scalar[1] != 1) {
 /*  fprintf(stdout, "input_dim_array_scalar[0] = %d\n", input_dim_array_scalar[0]); */
 /*  fprintf(stdout, "input_dim_array_scalar[1] = %d\n", input_dim_array_scalar[1]); */
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("STEPSIZE must be a SCALAR input argument.");
	}
   }
   stepsize = mxGetScalar(prhs[1]);
   if (stepsize <= 0.0) {
	   mexErrMsgTxt("STEPSIZE must be greater than 0.");
   }

 /*  mexPrintf("3 nrhs = %d\n", nrhs); */

 /*  think about this - bool mxIsEmpty(const mxArray *array_ptr); */
if ((nrhs >= 3) &&  !mxIsEmpty(prhs[2]) ) {
 /*  mexPrintf("3.1 nrhs = %d\n", nrhs); */
   number_of_dims_xbegin = mxGetNumberOfDimensions(prhs[2]);
 /*  mexPrintf("3.2 nrhs = %d\n", nrhs); */
   if (number_of_dims_xbegin != 2) {
        mexPrintf(
	   "usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
        mexErrMsgTxt("XBEGIN is a 2 D matrix of integer indices.");
   }
   input_dim_array_xbegin = mxGetDimensions(prhs[2]);
   if (input_dim_array_xbegin[0] != ny | input_dim_array_xbegin[1] != nz) {
        mexPrintf(
	   "usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
        mexErrMsgTxt(
	   "dimensions of XBEGIN must be the same as *ny* and *nz* for SAR");
   }
 /*  mexPrintf("3.9\n"); */

   int_xbegin = (int *) mxCalloc(ny * nz, sizeof(int));
   ixptr = int_xbegin;
   double_xbegin = mxGetPr(prhs[2]);
   dxptr = double_xbegin;
   for (iy = 0; iy < ny; iy++) { 
	for (iz = 0; iz < nz; iz++, ixptr++, dxptr++) { 
	   *ixptr = double_round(*dxptr) - 1;  /*  convert matlab to C indexing */
	}
   }
}
else {
 /*  fill up the array with ones or zeros (probably ones for matlab format, */
 /*  zeros for C language) */
   int_xbegin = (int *) mxCalloc(ny * nz, sizeof(int));
   ixptr = int_xbegin;
   for (iy = 0; iy < ny; iy++) { 
	for (iz = 0; iz < nz; iz++, ixptr++) { 
	   *ixptr = 0;  /*  should instead probably start on the second point */
	}
   }
}


 /*  mexPrintf("4\n"); */

if ((nrhs >=4 ) &&  !mxIsEmpty(prhs[3]) ) {
   number_of_dims_scalar = mxGetNumberOfDimensions(prhs[3]);
   input_dim_array_scalar = mxGetDimensions(prhs[3]);
   if (number_of_dims_scalar == 1) {
	if (input_dim_array_scalar[0] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("WB must be a SCALAR input argument.");
	}
   }
   else {
	if (input_dim_array_scalar[0] * input_dim_array_scalar[1] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("WB must be a SCALAR input argument.");
	}
   }
   wb = mxGetScalar(prhs[3]);
   if (wb < 0.0 | wb > 10.0) {
	   mexErrMsgTxt("WB should be between 0 and 10.");
   }
}
else {
   wb = 5.0;
}

 /*  mexPrintf("5\n"); */

if (( nrhs >= 5) && !mxIsEmpty(prhs[4]) ) {
   number_of_dims_scalar = mxGetNumberOfDimensions(prhs[4]);
   input_dim_array_scalar = mxGetDimensions(prhs[4]);
   if (number_of_dims_scalar == 1) {
	if (input_dim_array_scalar[0] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("TEMPBOUNDARY must be a SCALAR input argument.");
	}
   }
   else {
	if (input_dim_array_scalar[0] * input_dim_array_scalar[1] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("TEMPBOUNDARY must be a SCALAR input argument.");
	}
   }
   tempboundary = mxGetScalar(prhs[4]);
}
else {
   tempboundary = 3.0;
}

 /*  mexPrintf("6\n"); */

if ((nrhs >= 6) &&  !mxIsEmpty(prhs[5]) ) {
   number_of_dims_scalar = mxGetNumberOfDimensions(prhs[5]);
   input_dim_array_scalar = mxGetDimensions(prhs[5]);
   if (number_of_dims_scalar == 1) {
	if (input_dim_array_scalar[0] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("ITER must be a SCALAR input argument.");
	}
   }
   else {
	if (input_dim_array_scalar[0] * input_dim_array_scalar[1] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("ITER must be a SCALAR input argument.");
	}
   }
   iter = double_round(mxGetScalar(prhs[5]));
}
else {
   iter = 100;
}

 /*  mexPrintf("7\n"); */

if ((nrhs >= 7) && !mxIsEmpty(prhs[6]) ) {
   number_of_dims_scalar = mxGetNumberOfDimensions(prhs[6]);
   input_dim_array_scalar = mxGetDimensions(prhs[6]);
   if (number_of_dims_scalar == 1) {
	if (input_dim_array_scalar[0] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("MU must be a SCALAR input argument.");
	}
   }
   else {
	if (input_dim_array_scalar[0] * input_dim_array_scalar[1] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("MU must be a SCALAR input argument.");
	}
   }
   mu = mxGetScalar(prhs[6]);
   if (mu < 1.0 | mu > 2.0) {
	   mexErrMsgTxt("MU should be between 1 and 2, inclusive.");
   }
}
else {
   mu = 1.86;
}

 /*  mexPrintf("8\n"); */

if ((nrhs >= 8) &&  !mxIsEmpty(prhs[7]) ) {
   number_of_dims_scalar = mxGetNumberOfDimensions(prhs[7]);
   input_dim_array_scalar = mxGetDimensions(prhs[7]);
   if (number_of_dims_scalar == 1) {
	if (input_dim_array_scalar[0] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("KAPPA must be a SCALAR input argument.");
	}
   }
   else {
	if (input_dim_array_scalar[0] * input_dim_array_scalar[1] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("KAPPA must be a SCALAR input argument.");
	}
   }
   kappa = mxGetScalar(prhs[7]);
   if (kappa <= 0.0 ) {
	   mexErrMsgTxt("KAPPA must be greater than 0.");
   }
}
else {
   kappa = 0.55;
}

 /*  mexPrintf("9\n"); */

if ((nrhs >= 9) &&   !mxIsEmpty(prhs[8]) ) {
   number_of_dims_scalar = mxGetNumberOfDimensions(prhs[8]);
   input_dim_array_scalar = mxGetDimensions(prhs[8]);
   if (number_of_dims_scalar == 1) {
	if (input_dim_array_scalar[0] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("KAPPA must be a SCALAR input argument.");
	}
   }
   else {
	if (input_dim_array_scalar[0] * input_dim_array_scalar[1] != 1) {
           mexPrintf(
		"usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
	   mexErrMsgTxt("KAPPA must be a SCALAR input argument.");
	}
   }
   cb = mxGetScalar(prhs[8]);
   if (cb <= 0.0 ) {
	   mexErrMsgTxt("CB must be greater than 0.");
   }
}
else {
   cb = 4000.0;
}

 /*  mexPrintf("10\n"); */

if ((nrhs >= 10) &&    !mxIsEmpty(prhs[9]) ) {
   number_of_dims_xend = mxGetNumberOfDimensions(prhs[9]);
   if (number_of_dims_xend != 2) {
        mexPrintf(
	   "usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
        mexErrMsgTxt("XEND is a 2 D matrix of integer indices.");
   }
   input_dim_array_xend = mxGetDimensions(prhs[9]);
   if (input_dim_array_xend[0] != ny | input_dim_array_xend[1] != nz) {
        mexPrintf(
	   "usage: [TEMPRISE] = BHTE(SAR, STEPSIZE, XBEGIN, WB, ...);\n");
        mexErrMsgTxt(
	   "dimensions of XEND must be the same as *ny* and *nz* for SAR");
   }
}
else {
 /*  fill up the array with nx or nx - 1 (probably former for matlab format, */
 /*  latter for C language) */
}

 /*  mexPrintf("11\n"); */

 /*    plhs[0] = mxCreateDoubleMatrix(1, n, mxREAL); */
 /*    plhs[1] = mxCreateDoubleMatrix(1, n, mxREAL); */

 /*    abscissas = mxGetPr(plhs[0]); */
 /*    weights = mxGetPr(plhs[1]); */

 /*  start by setting the temperature rise everywhere to zero */
ptrtemp = temprise;
ixptr = int_xbegin;
for (iz = 0; iz < nz; iz++) { 
   for (iy = 0; iy < ny; iy++, ixptr++) { 
	for (ix = 0; ix < *ixptr; ix++, ptrtemp++) { 
	   *ptrtemp = tempboundary;
	}
	for (; ix < nx; ix++, ptrtemp++) { 
	   *ptrtemp = 0.0;
	}
   }
}

 /*  first x slice */
/*
ptrtemp = temprise;
for (iz = 0; iz < nz; iz++) { 
   for (iy = 0; iy < ny; iy++, ptrtemp++) { 
	*ptrtemp = tempboundary;
   }
}
*/

/*  first y slice */
/*  last y */
/*
for (ix = 0; ix < nx; ix++) { 
   for (iz = 0; iz < nz; iz++) { 
	temprise[iz * nx * ny + 0 * nx + ix] = tempboundary;  
	temprise[iz * nx * ny + (ny - 1) * nx + ix] = tempboundary;  
   }
}
*/

/*
for (ix = 0; ix < nx; ix++) { 
   for (iy = 0; iy < ny; iy++) { 
   }
}
*/

for (i = 0; i < iter; i++) { 
   for (iz = 1; iz < (nz - 1); iz++) {
	for (iy = 1; iy < (ny - 1); iy++) { 
	   for (ix = int_xbegin[iz * ny + iy]; ix < (nx - 1); ix++) { 
		temprise[nx * (iz * ny + iy) + ix] = mu * kappa / 
                   (6 * kappa + pow(stepsize, 2.0) * wb * cb) * 
                   (pow(stepsize, 2.0) / kappa * sar[nx * (iz * ny + iy) + ix] 
		   + temprise[nx * (iz * ny + iy) + ix + 1] 
		   + temprise[nx * (iz * ny + iy) + ix - 1] 
		   + temprise[nx * (iz * ny + iy + 1) + ix] 
		   + temprise[nx * (iz * ny + iy - 1) + ix] 
		   + temprise[nx * ((iz + 1) * ny + iy) + ix] 
		   + temprise[nx * ((iz - 1) * ny + iy) + ix] )
		   + (1.0 - mu) * temprise[nx * (iz * ny + iy) + ix];
	   }
	}
   }
}

 /* 	   for (ix = 1; ix < (nx - 1); ix++, ptrtemp++, ptrsar++) { } */
/*
for (i = 0; i < iter; i++) { 
   ptrsar = sar + nx * ny + nx + 1;
   ptrtemp = temprise + nx * ny + nx + 1;
   ixptr = int_xbegin + ny + 1;
   for (iz = 1; iz < (nz - 1); iz++, ptrsar += 2 * nx, ptrtemp += 2 * nx, 
	ixptr +=2) { 
	for (iy = 1; iy < (ny - 1); iy++, ixptr++, ptrsar += 2, ptrtemp += 2) { 
	   ptrsar += (*ixptr) - 1; 
	   ptrtemp += (*ixptr) - 1; 
	   for (ix = *ixptr; ix < (nx - 1); ix++, ptrtemp++, ptrsar++) { 
                (*ptrtemp) = mu * kappa / 
                   (6 * kappa + pow(stepsize, 2.0) * wb * cb) * 
                   (pow(stepsize, 2.0) / kappa *  (*ptrsar)  
		   + *(ptrtemp + 1) + *(ptrtemp - 1)
		   + *(ptrtemp + nx) + *(ptrtemp - nx)
		   + *(ptrtemp + nx * ny) + *(ptrtemp - nx * ny) )
		   + (1.0 - mu) *   (*ptrtemp);
	   }
	}
   }
}
*/

/*
for (iz = 0; iz < nz; iz++) { 
   for (iy = 0; iy < ny; iy++, ixptr++) { 
	for (ix = 0; ix < *ixptr; ix++, ptrtemp++) { 
	   *ptrtemp = tempboundary;
	}
	for (; ix < nx; ix++, ptrtemp++) { 
	   *ptrtemp = 0.0;
	}
   }
}
*/

/* 
                for(k = 1; k < nzzm1; k++, power_ptr += 2 * nxx,
                   res_ptr += 2 * nxx, new_ptr += 2 * nxx, old_ptr += 2 * nxx) {
                   for (j = 1; j < nyym1; j++, power_ptr += 2, new_ptr += 2,
                        res_ptr += 2, old_ptr += 2) {
                        for (i = 1; i < nxxm1; i++, power_ptr++, new_ptr++,
                           res_ptr++, old_ptr++) {
                           tot = KVISCERA * (*(new_ptr + 1) + *(new_ptr - 1)
                                + *(new_ptr + nxx) + *(new_ptr - nxx)
                                + *(new_ptr + nxx * nyy)
                                + *(new_ptr - nxx * nyy));
                           *new_ptr = kons * (tot + (*res_ptr))
                             + (1.0 - RELAXPARAM) * (*old_ptr);
                        }
                   }
                }
*/ 

 /*  mexPrintf("12\n"); */

/*
   for iz = 2:(nz - 1),
        for iy = 2:(ny - 1),
           for ix = xbegin(iy, iz):(nx - 1);
                temprise(ix, iy, iz) = mu * kappa / 
                   (6 * kappa + stepsize^2 * wb * cb) * 
                   (stepsize^2 / kappa * sar(ix, iy, iz)  
+ temprise(ix + 1, iy, iz) + temprise(ix - 1, iy, iz) 
+ temprise(ix, iy + 1, iz) + temprise(ix, iy - 1, iz) 
+ temprise(ix, iy, iz + 1) + temprise(ix, iy, iz - 1)) 
+ (1 - mu) * temprise(ix, iy, iz);
           end
        end
   end
end
*/

 /*  mexPrintf("13\n"); */

}
    

int
double_round(double_value)
double double_value;
{
   int int_value;
   if (double_value >= 0.0) {
        int_value = double_value + 0.5;
   }
   else {
        int_value = double_value - 0.5;
   }     
 
return(int_value);
}


