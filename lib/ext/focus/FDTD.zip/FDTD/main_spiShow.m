% Nov 2008 by Ruihua Ding, All rights reserved. 
% If used the following program, should mention the author and her
% associate insistution: 
% Biomedical Ultrasonics and Electromagnetics Lab. 
% Director: Prof Robert McGough, Michigan State University, Electrical Engineering
% department. 

% This program obtain the power distribution in human body by RF
% applicators by Finite Difference Time Domain method. 
% 
% RF applicator is spiral antenna, working at 433MHz;
% chest model is derived from CT scan images of patients; which is loaded
% by data file as "chrot2spi.mat"
% output: calculated electric power and SAR deposition in the human body.
% Theshow SAR distribution for every 30 time steps.

% Yee cell size = 1mm; 
% ABC(Absorbing boundary condition): PML(perfect match layers)
%***********************************************************************
%     Fundamental constants
%***********************************************************************
clc
clear
cc=2.99792458e8;            %speed of light in free space
muz=4.0*pi*1.0e-7;          %permeability of free space
epsz=1.0/(cc*cc*muz);       %permittivity of free space

freq=433e+6;                %center frequency of source excitation
lamda=cc/freq;              %center wavelength of source excitation
omega=2.0*pi*freq;    

%***********************************************************************
%    define the simulation domain
%***********************************************************************
global dx1 iw jw kw
dx=0.001;           %space increment of cube lattice dx=dy=dz
dx1=dx*100;         %cm
dt=dx/(2.0*cc);     %time step

dimx=20;   
dimy=11;
dimz=11;

io=ceil(dimx/dx1);
jo=ceil(dimy/dx1);
ko=ceil(dimz/dx1);

iw=2;               %floor(lamda/2/dx);
jw=20;
kw=0;

ie=io+iw*2;       %number of grid cells in x-direction
je=jo+jw*2;       %number of grid cells in y-direction
ke=ko+kw;         %number of grid cells in z-direction

% note: ie, je, ke is the total # of cells for the simulation domain.
% io, jo, ko shows the size of the imported human model cell by the data
% file. It is the inhomogeneous part of the simulation domain.
%iw, jw, kw shows the surrounded homogenous material of the simulation
%domain. 
%In this program, it is water. Because the human tissue is heated by the RF
%applicator in water. 

% The extra homogeneous part controled by iw, jw and kw can help the
% programmer to shrink the imported data size. If not needed, then can be
% assigned = 0. 

% excitation source will be in object domain and the field we concerned in
% this prgram only exist in object domain.

ib=ie+1;
jb=je+1;
kb=ke+1;

nmax=8400;         %total number of time steps

iebc=10;             %thickness of left and right PML region
jebc=16;             %thickness of front and back PML region
kebc=32;             %thickness of up and down PML region
rmax=0.000001;       %10-cell thick rmax 
orderbc=3;          %rank
ibbc=iebc+1;
jbbc=jebc+1;
kbbc=kebc+1;
iefbc=ie+2*iebc; 
jefbc=je+2*jebc;
kefbc=ke+2*kebc;
ibfbc=iefbc+1;
jbfbc=jefbc+1;
kbfbc=kefbc+1;

%***********************************************************************
%     Field arrays
%***********************************************************************
ex=zeros(ie,jb,kb);               %fields in main grid 
ey=zeros(ib,je,kb);
ez=zeros(ib,jb,ke);

Etotal=zeros(ie-2*iw-1, je-2*jw-1, ke-2*kw-1); 

hx=zeros(ib,je,ke);
hy=zeros(ie,jb,ke);
hz=zeros(ie,je,kb);

exybcf=zeros(iefbc,jebc,kbfbc);   %fields in front PML region
exzbcf=zeros(iefbc,jebc,kbfbc);
eyxbcf=zeros(ibfbc,jebc,kbfbc);
eyzbcf=zeros(ibfbc,jebc,kbfbc);
ezxbcf=zeros(ibfbc,jebc,kefbc);
ezybcf=zeros(ibfbc,jebc,kefbc);

hxybcf=zeros(ibfbc,jebc,kefbc);
hxzbcf=zeros(ibfbc,jebc,kefbc);
hyxbcf=zeros(iefbc,jebc,kefbc);
hyzbcf=zeros(iefbc,jebc,kefbc);
hzxbcf=zeros(iefbc,jebc,kbfbc);
hzybcf=zeros(iefbc,jebc,kbfbc);

exybcb=zeros(iefbc,jbbc,kbfbc);   %fields in back PML region
exzbcb=zeros(iefbc,jbbc,kbfbc); 
eyxbcb=zeros(ibfbc,jebc,kbfbc);
eyzbcb=zeros(ibfbc,jebc,kbfbc);
ezxbcb=zeros(ibfbc,jbbc,kefbc);
ezybcb=zeros(ibfbc,jbbc,kefbc);

hxybcb=zeros(ibfbc,jebc,kefbc);
hxzbcb=zeros(ibfbc,jebc,kefbc);
hyxbcb=zeros(iefbc,jbbc,kefbc);
hyzbcb=zeros(iefbc,jbbc,kefbc);
hzxbcb=zeros(iefbc,jebc,kbfbc);
hzybcb=zeros(iefbc,jebc,kbfbc);

exybcl=zeros(iebc,jb,kbfbc);      %fields in left PML region
exzbcl=zeros(iebc,jb,kbfbc);
eyxbcl=zeros(iebc,je,kbfbc);
eyzbcl=zeros(iebc,je,kbfbc);
ezxbcl=zeros(iebc,jb,kefbc);
ezybcl=zeros(iebc,jb,kefbc);

hxybcl=zeros(iebc,je,kefbc);
hxzbcl=zeros(iebc,je,kefbc);
hyxbcl=zeros(iebc,jb,kefbc);
hyzbcl=zeros(iebc,jb,kefbc);
hzxbcl=zeros(iebc,je,kbfbc);
hzybcl=zeros(iebc,je,kbfbc);

exybcr=zeros(iebc,jb,kbfbc);      %fields in right PML region
exzbcr=zeros(iebc,jb,kbfbc);
eyxbcr=zeros(ibbc,je,kbfbc);
eyzbcr=zeros(ibbc,je,kbfbc);
ezxbcr=zeros(ibbc,jb,kefbc);
ezybcr=zeros(ibbc,jb,kefbc);

hxybcr=zeros(ibbc,je,kefbc);
hxzbcr=zeros(ibbc,je,kefbc);
hyxbcr=zeros(iebc,jb,kefbc);
hyzbcr=zeros(iebc,jb,kefbc);
hzxbcr=zeros(iebc,je,kbfbc);
hzybcr=zeros(iebc,je,kbfbc);

exybcd=zeros(ie,jb,kebc);        %fields in down PML region
exzbcd=zeros(ie,jb,kebc); 
eyxbcd=zeros(ib,je,kebc);
eyzbcd=zeros(ib,je,kebc);
ezxbcd=zeros(ib,jb,kebc);
ezybcd=zeros(ib,jb,kebc);

hxybcd=zeros(ib,je,kebc);
hxzbcd=zeros(ib,je,kebc);
hyxbcd=zeros(ie,jb,kebc);
hyzbcd=zeros(ie,jb,kebc);
hzxbcd=zeros(ie,je,kebc);
hzybcd=zeros(ie,je,kebc);

exybcu=zeros(ie,jb,kbbc);        %fields in up PML region
exzbcu=zeros(ie,jb,kbbc); 
eyxbcu=zeros(ib,je,kbbc);
eyzbcu=zeros(ib,je,kbbc);
ezxbcu=zeros(ib,jb,kebc);
ezybcu=zeros(ib,jb,kebc);

hxybcu=zeros(ib,je,kebc);
hxzbcu=zeros(ib,je,kebc);
hyxbcu=zeros(ie,jb,kebc);
hyzbcu=zeros(ie,jb,kebc);
hzxbcu=zeros(ie,je,kbbc);
hzybcu=zeros(ie,je,kbbc);
%***********************************************************************
%    load the human chest with tumor and applicator model. 
%***********************************************************************
load chrot2spi.mat

%***********************************************************************
%     Material parameters
%***********************************************************************

media=8;
air=1;   metalx=2;   water=3;    appfiller=4;  metaly=10;
skin=5;  fat=6;     tumor=7;    muscle=8;    

% (1)air,(2)metal,water(3),fill(4),skin(5) fat(6), tumor(7), muscle(8)  
eps=[76.5  1.0     76.5    2.1     46.7    11.6     57.1     58.8];
sig=[0.0  1.0e+7   0.0     0.0     0.69    0.08     1.16     0.84];
row=[1e6    0.0    1e6     0.0     1010    920      1177     1041];

sig(9)=sig(muscle);  sig(metaly)=sig(metalx); 
row(9)=row(muscle);  row(metaly)=row(metalx);

% in humanbody, all the mur and sim is the same
mur=1.0;
sim=0.0;

save para4SAR.mat ie je ke iw jw kw sig row
%***********************************************************************
%     Updating coefficients
%***********************************************************************

for m=1:media
  eaf=dt*sig(m)/(2.0*epsz*eps(m));
  ca(m)=(1.0-eaf)/(1.0+eaf);
  cb(m)=dt/epsz/eps(m)/dx/(1.0+eaf);
end

ca(9)=ca(muscle);    cb(9)=cb(muscle);

ca(metaly)=ca(metalx);  cb(metaly)=cb(metalx);

haf=dt*sim/(2.0*muz*mur);
da(1)=(1.0-haf)/(1.0+haf);
db(1)=dt/muz/mur/dx/(1.0+haf);
%***********************************************************************
%     Geometry specification (main grid) and initialize for PML
%***********************************************************************
front=1;
back=2;
left=3;
right=4;
down=5;
up=6;

%***********************************************************************
%     Fill the PML regions
%***********************************************************************
% air in front of PML
epsz=epsz*eps(3);  %--water in front of PML

delbc=iebc*dx;
sigmam=-log(rmax/100.00)*epsz*cc*(orderbc+1)/(2*delbc);
bcfactor=eps(1)*sigmam/(dx*(delbc^orderbc)*(orderbc+1));

%     l("front") region 
    %     sigmay
    
for l=2:jebc
  y1=(jebc-l+1.5)*dx;
  y2=(jebc-l+0.5)*dx;
  sigmay=bcfactor*(y1^(orderbc+1)-y2^(orderbc+1));
  ca1=exp(-sigmay*dt/(epsz*eps(1)));
  cb1=(1.0-ca1)/(sigmay*dx);
  caexyf(l)=ca1;        
  cbexyf(l)=cb1;        
  caezyf(l)=ca1;        
  cbezyf(l)=-cb1;      
end
sigmay = bcfactor*(0.5*dx)^(orderbc+1);
ca1=exp(-sigmay*dt/(epsz*eps(1)));
cb1=(1-ca1)/(sigmay*dx);

caex(front)=ca1;       
cbex(front)=cb1;       
caez(front)=ca1;        
cbez(front)=cb1;       

caexyl(front)=ca1;        
cbexyl(front)=cb1;        
caezyl(front)=ca1;        
cbezyl(front)=-cb1;       

caexyr(front)=ca1;        
cbexyr(front)=cb1;        %
caezyr(front)=ca1;       
cbezyr(front)=-cb1;       %

caexyd(front)=ca1;        
cbexyd(front)=cb1;        %
caezyd(front)=ca1;        
cbezyd(front)=-cb1;       %

caexyu(front)=ca1;       
cbexyu(front)=cb1;        %
caezyu(front)=ca1;        
cbezyu(front)=-cb1;       %

%     sigmays
for l=1:jebc
  y1=(jebc-l+1)*dx;
  y2=(jebc-l)*dx;
  sigmay=bcfactor*(y1^(orderbc+1)-y2^(orderbc+1));
  sigmays=sigmay*(muz/(epsz*eps(1)));
  da1=exp(-sigmays*dt/muz);
  db1=(1-da1)/(sigmays*dx);
  dahxyf(l)=da1;       
  dbhxyf(l)=-db1;       %
  dahzyf(l)=da1;      
  dbhzyf(l)=db1;        %
end

%       l("back") region 

for l=2:jebc
  y1=(l-0.5)*dx;
  y2=(l-1.5)*dx;
  sigmay=bcfactor*(y1^(orderbc+1)-y2^(orderbc+1));
  ca1=exp(-sigmay*dt/(epsz*eps(1)));
  cb1=(1-ca1)/(sigmay*dx);
  caexyb(l)=ca1;        
  caezyb(l)=ca1;       
  cbexyb(l)=cb1;
  cbezyb(l)=-cb1;
end
sigmay = bcfactor*(0.5*dx)^(orderbc+1);
ca1=exp(-sigmay*dt/(epsz*eps(1)));
cb1=(1-ca1)/(sigmay*dx);

caex(back)=ca1;       
cbex(back)=cb1;
caez(back)=ca1;       
cbez(back)=cb1;

caexyl(back)=ca1;    
cbexyl(back)=cb1;
caezyl(back)=ca1;    
cbezyl(back)=-cb1;

caexyr(back)=ca1;     
cbexyr(back)=cb1;
caezyr(back)=ca1;     
cbezyr(back)=-cb1;

caexyd(back)=ca1;    
cbexyd(back)=cb1;
caezyd(back)=ca1;     
cbezyd(back)=-cb1;

caexyu(back)=ca1;     
cbexyu(back)=cb1;
caezyu(back)=ca1;     
cbezyu(back)=-cb1;

    %     sigmays
for l=1:jebc
  y1=l*dx;
  y2=(l-1)*dx;
  sigmay=bcfactor*(y1^(orderbc+1)-y2^(orderbc+1));
  sigmays=sigmay*(muz/(epsz*eps(1)));
  da1=exp(-sigmays*dt/muz);
  db1=(1-da1)/(sigmays*dx);
  dahxyb(l)=da1;        
  dbhxyb(l)=-db1;
  dahzyb(l)=da1;        
  dbhzyb(l)=db1;
 
end


%     X--m("left") region 

for m=2:iebc
  x1=(iebc-m+1.5)*dx;
  x2=(iebc-m+0.5)*dx;
  sigmax=bcfactor*(x1^(orderbc+1)-x2^(orderbc+1));
  ca1=exp(-sigmax*dt/(epsz*eps(1)));
  cb1=(1-ca1)/(sigmax*dx);
  caeyxl(m)=ca1;       
  cbeyxl(m)=-cb1;
  caezxl(m)=ca1;       
  cbezxl(m)=cb1;
  
  caeyxf(m,left)=ca1;     
  cbeyxf(m,left)=-cb1;
  caezxf(m,left)=ca1;     
  cbezxf(m,left)=cb1;
  
  caeyxb(m,left)=ca1;     
  cbeyxb(m,left)=-cb1;
  caezxb(m,left)=ca1;     
  cbezxb(m,left)=cb1;

end
sigmax=bcfactor*(0.5*dx)^(orderbc+1);
ca1=exp(-sigmax*dt/(epsz*eps(1)));
cb1=(1-ca1)/(sigmax*dx);

caey(left)=ca1;         %interface between PML and inner field
cbey(left)=cb1;         %cbey(1,1:je,1:kb)=cb1;
caez(left)=ca1;
cbez(left)=cb1;         %cbez(1,1:jb,1:ke)=cb1;

caeyxf(iebc+1,left)=ca1;    %interface between left and front 
cbeyxf(iebc+1,left)=-cb1;   %
caezxf(iebc+1,left)=ca1;
cbezxf(iebc+1,left)=cb1;    %

caeyxb(iebc+1,left)=ca1;    %interface between left and back
cbeyxb(iebc+1,left)=-cb1;       %
caezxb(iebc+1,left)=ca1;
cbezxb(iebc+1,left)=cb1;        %

caeyxd(left)=ca1;   %interface between left and down
cbeyxd(left)=-cb1;       %
caezxd(left)=ca1;
cbezxd(left)=cb1;        %

caeyxu(left)=ca1;    %interface between left and up
cbeyxu(left)=-cb1;       %cbeyxu(1,1:je,2:kbbc)=-cb1;
caezxu(left)=ca1;
cbezxu(left)=cb1;        %cbezxu(1,1:jb,1:kebc)=cb1;

for m=1:iebc
  x1=(iebc-m+1)*dx;
  x2=(iebc-m)*dx;
  sigmax=bcfactor*(x1^(orderbc+1)-x2^(orderbc+1));
  sigmaxs=sigmax*(muz/(epsz*eps(1)));
  da1=exp(-sigmaxs*dt/muz);
  db1=(1-da1)/(sigmaxs*dx);

  dahyxl(m)=da1;                %dahyxl(m,1:jb,1:kefbc)=da1;
  dbhyxl(m)=db1;
  dahzxl(m)=da1;                %dahzxl(m,1:je,1:kbfbc)=da1;
  dbhzxl(m)=-db1;
  
  dahyxf(m,left)=da1;           %interface between left and front 
  dbhyxf(m,left)=db1;           %dbhyxf(m,1:jebc,1:kefbc)=db1;
  dahzxf(m,left)=da1;
  dbhzxf(m,left)=-db1;          %  dbhzxf(m,1:jebc,1:kbfbc)=-db1;
  
  dahyxb(m,left)=da1;           %interface between left and back
  dbhyxb(m,left)=db1;           %dbhyxb(m,1:jbbc,1:kefbc)=db1; 
  dahzxb(m,left)=da1;
  dbhzxb(m,left)=-db1;          %dbhzxb(m,1:jebc,1:kbfbc)=-db1;
  
end

%     m("right") region 

for m=2:iebc
  x1=(m-0.5)*dx;
  x2=(m-1.5)*dx;
  sigmax=bcfactor*(x1^(orderbc+1)-x2^(orderbc+1));
  ca1=exp(-sigmax*dt/(epsz*eps(1)));
  cb1=(1-ca1)/(sigmax*dx);
  caeyxr(m)=ca1;        % caeyxr(m,1:je,1:kbfbc)=ca1;
  cbeyxr(m)=-cb1;
  caezxr(m)=ca1;        % caezxr(m,1:jb,1:kefbc)=ca1;
  cbezxr(m)=cb1;

  caeyxf(m,right)=ca1;       % caeyxf(m+iebc+ie,1:jebc,1:kbfbc)=ca1;
  cbeyxf(m,right)=-cb1;
  caezxf(m,right)=ca1;       % caezxf(m+iebc+ie,1:jebc,1:kefbc)=ca1;
  cbezxf(m,right)=cb1;
  
  caeyxb(m,right)=ca1;       % caeyxb(m+iebc+ie,1:jebc,1:kbfbc)=ca1;
  cbeyxb(m,right)=-cb1;
  caezxb(m,right)=ca1;       % caezxb(m+iebc+ie,1:jbbc,1:kefbc)=ca1;
  cbezxb(m,right)=cb1;
end
sigmax=bcfactor*(0.5*dx)^(orderbc+1);
ca1=exp(-sigmax*dt/(epsz*eps(1)));
cb1=(1-ca1)/(sigmax*dx);

caey(right)=ca1;         %caey(ib,1:je,1:kb)=ca1; 
cbey(right)=cb1;
caez(right)=ca1;        %caez(ib,1:jb,1:ke)=ca1;
cbez(right)=cb1;

caeyxf(1,right)=ca1;     %caeyxf(iebc+ib,1:jebc,1:kbfbc)=ca1; 
cbeyxf(1,right)=-cb1;
caezxf(1,right)=ca1;     %caezxf(iebc+ib,1:jebc,1:kefbc)=ca1;
cbezxf(1,right)=cb1;

caeyxb(1,right)=ca1;    %interface between right and back
cbeyxb(1,right)=-cb1;   %cbeyxb(iebc+ib,1:jebc,1:kbfbc)=-cb1;
caezxb(1,right)=ca1;
cbezxb(1,right)=cb1;    %cbezxb(iebc+ib,2:jbbc,1:kefbc)=cb1;

caeyxd(right)=ca1;   %interface between left and down
cbeyxd(right)=-cb1;   %cbeyxd(ib,1:je,1:kebc)=-cb1;
caezxd(right)=ca1;
cbezxd(right)=cb1;    %cbezxd(ib,1:jb,1:kebc)=cb1; 

caeyxu(right)=ca1;    %interface between left and up
cbeyxu(right)=-cb1;   %cbeyxu(ib,1:je,2:kbbc)=-cb1;
caezxu(right)=ca1;
cbezxu(right)=cb1;    %cbezxu(ib,1:jb,1:kebc)=cb1; 

for m=1:iebc
  x1=m*dx;
  x2=(m-1)*dx;
  sigmax=bcfactor*(x1^(orderbc+1)-x2^(orderbc+1));
  sigmaxs=sigmax*(muz/(epsz*eps(1)));
  da1=exp(-sigmaxs*dt/muz);
  db1=(1-da1)/(sigmaxs*dx);
  dahyxr(m)=da1;                          %dahyxr(m,1:jb,1:kefbc)=da1; 
  dbhyxr(m)=db1;
  dahzxr(m)=da1;                          %  dahzxr(m,1:je,1:kbfbc)=da1; 
  dbhzxr(m)=-db1;
  
  dahyxf(m,right)=da1;           %interface between left and front 
  dbhyxf(m,right)=db1;           %dbhyxf(m+ie+iebc,1:jebc,1:kefbc)=db1;
  dahzxf(m,right)=da1;
  dbhzxf(m,right)=-db1;           %dbhzxf(m+ie+iebc,1:jebc,1:kbfbc)=-db1; 
  
  dahyxb(m,right)=da1;           %interface between left and backb
  dbhyxb(m,right)=db1;           %dbhyxb(m+ie+iebc,1:jbbc,1:kefbc)=db1; 
  dahzxb(m,right)=da1;
  dbhzxb(m,right)=-db1;          %dbhzxb(m+ie+iebc,1:jebc,1:kbfbc)=-db1;
  
end
 
%      K("down") region 

for k=2:kebc
  z1=(kebc-k+1.5)*dx;
  z2=(kebc-k+0.5)*dx;
  sigmaz=bcfactor*(z1^(orderbc+1)-z2^(orderbc+1));
  ca1=exp(-sigmaz*dt/(epsz*eps(1)));
  cb1=(1-ca1)/(sigmaz*dx);
  caexzd(k)=ca1;          % caexzd(1:ie,1:jb,k)=ca1;  
  cbexzd(k)=-cb1;
  caeyzd(k)=ca1;          % caeyzd(1:ib,1:je,k)=ca1;
  cbeyzd(k)=cb1;

  caexzf(k,down)=ca1;          % caexzf(1:iefbc,1:jebc,k)=ca1;         
  cbexzf(k,down)=-cb1;
  caeyzf(k,down)=ca1;          %  caeyzf(1:ibfbc,1:jebc,k)=ca1;      
  cbeyzf(k,down)=cb1;
  
  caexzb(k,down)=ca1;          %caexzb(1:iefbc,1:jbbc,k)=ca1;
  cbexzb(k,down)=-cb1;
  caeyzb(k,down)=ca1;          %caeyzb(1:ibfbc,1:jebc,k)=ca1; 
  cbeyzb(k,down)=cb1;
  
  caexzl(k,down)=ca1;          % caexzl(1:iebc,1:jb,k)=ca1; 
  cbexzl(k,down)=-cb1;
  caeyzl(k,down)=ca1;          % caeyzl(1:iebc,1:je,k)=ca1;
  cbeyzl(k,down)=cb1;
  
  caexzr(k,down)=ca1;          % caexzr(1:iebc,1:jb,k)=ca1; 
  cbexzr(k,down)=-cb1;
  caeyzr(k,down)=ca1;          % caeyzr(1:ibbc,1:je,k)=ca1; 
  cbeyzr(k,down)=cb1;

end
sigmaz=bcfactor*(0.5*dx)^(orderbc+1);
ca1=exp(-sigmaz*dt/(epsz*eps(1)));
cb1=(1-ca1)/(sigmaz*dx);

caex(down)=ca1;
cbex(down)=cb1;
caey(down)=ca1;
cbey(down)=cb1;

caexzf(kebc+1,down)=ca1;    %interface between down and front     
cbexzf(kebc+1,down)=-cb1;
caeyzf(kebc+1,down)=ca1;        %caeyzf(1:ibfbc,1:jebc,kebc+1)=ca1;
cbeyzf(kebc+1,down)=cb1;

caexzb(kebc+1,down)=ca1;         %interface between down and back
cbexzb(kebc+1,down)=-cb1;
caeyzb(kebc+1,down)=ca1;        %caeyzb(1:ibfbc,1:jebc,kebc+1)=ca1;
cbeyzb(kebc+1,down)=cb1;

caexzl(kebc+1,down)=ca1;       %interface between down and left
cbexzl(kebc+1,down)=-cb1;
caeyzl(kebc+1,down)=ca1;        %caeyzl(1:iebc,1:je,kebc+1)=ca1;
cbeyzl(kebc+1,down)=cb1;
  
caexzr(kebc+1,down)=ca1;        %interface between down and right
cbexzr(kebc+1,down)=-cb1;
caeyzr(kebc+1,down)=ca1;        %caeyzr(2:ibbc,1:je,kebc+1)=ca1;
cbeyzr(kebc+1,down)=cb1;

for k=1:kebc
  k1=(kebc-k+1)*dx;
  k2=(kebc-k)*dx;
  sigmak=bcfactor*(k1^(orderbc+1)-k2^(orderbc+1));
  sigmaks=sigmak*(muz/(epsz*eps(1)));
  da1=exp(-sigmaks*dt/muz);
  db1=(1-da1)/(sigmaks*dx);

  dahxzd(k)=da1;          %dahxzd(1:ib,1:je,k)=da1;
  dbhxzd(k)=db1;
  dahyzd(k)=da1;         %dahyzd(1:ie,1:jb,k)=da1; 
  dbhyzd(k)=-db1;

  dahxzf(k,down)=da1;           %region between down and front 
  dbhxzf(k,down)=db1;         %dbhxzf(1:ibfbc,1:jebc,k)=db1;
  dahyzf(k,down)=da1;
  dbhyzf(k,down)=-db1;         %dbhyzf(1:iefbc,1:jebc,k)=-db1;
  
  dahxzb(k,down)=da1;           %region between down and back
  dbhxzb(k,down)=db1;          %dbhxzb(1:ibfbc,1:jebc,k)=db1;  
  dahyzb(k,down)=da1;
  dbhyzb(k,down)=-db1;         %dbhyzb(1:iefbc,1:jbbc,k)=-db1; 
  
  dahxzl(k,down)=da1;              %region between down and left
  dbhxzl(k,down)=db1;          %dbhxzl(1:iebc,1:je,k)=db1; 
  dahyzl(k,down)=da1;
  dbhyzl(k,down)=-db1;         %dbhyzl(1:iebc,1:jb,k)=-db1;
  
  dahxzr(k,down)=da1;              %region between down and right
  dbhxzr(k,down)=db1;         %dbhxzr(1:ibbc,1:je,k)=db1;
  dahyzr(k,down)=da1;
  dbhyzr(k,down)=-db1;         %dbhyzr(1:iebc,1:jb,k)=-db1; 
  
end

%      K("up") region 

for k=2:kebc
  z1=(k-0.5)*dx;
  z2=(k-1.5)*dx;
  sigmaz=bcfactor*(z1^(orderbc+1)-z2^(orderbc+1));
  ca1=exp(-sigmaz*dt/(epsz*eps(1)));
  cb1=(1-ca1)/(sigmaz*dx);
  caexzu(k)=ca1;         %caexzu(1:ie,1:jb,k)=ca1;
  cbexzu(k)=-cb1;
  caeyzu(k)=ca1;         %caeyzu(1:ib,1:je,k)=ca1;
  cbeyzu(k)=cb1;

  caexzf(k,up)=ca1;              %  caexzf(1:iefbc,1:jebc,k+kebc+ke)=ca1;  
  cbexzf(k,up)=-cb1;
  caeyzf(k,up)=ca1;              % caeyzf(1:ibfbc,1:jebc,k+kebc+ke)=ca1; 
  cbeyzf(k,up)=cb1;
  
  caexzb(k,up)=ca1;         %caexzb(1:iefbc,1:jbbc,k+kebc+ke)=ca1; 
  cbexzb(k,up)=-cb1;
  caeyzb(k,up)=ca1;         %caeyzb(1:ibfbc,1:jebc,k+kebc+ke)=ca1;  
  cbeyzb(k,up)=cb1;
  
  caexzl(k,up)=ca1;         % caexzl(1:iebc,1:jb,k+kebc+ke)=ca1; 
  cbexzl(k,up)=-cb1;
  caeyzl(k,up)=ca1;         % caeyzl(1:iebc,1:je,k+kebc+ke)=ca1;  
  cbeyzl(k,up)=cb1;
  
  caexzr(k,up)=ca1;         %caexzr(1:iebc,1:jb,k+kebc+ke)=ca1; 
  cbexzr(k,up)=-cb1;
  caeyzr(k,up)=ca1;         %caeyzr(1:ibbc,1:je,k+kebc+ke)=ca1;  
  cbeyzr(k,up)=cb1;

end
sigmaz=bcfactor*(0.5*dx)^(orderbc+1);
ca1=exp(-sigmaz*dt/(epsz*eps(1)));
cb1=(1-ca1)/(sigmaz*dx);

caex(up)=ca1;
cbex(up)=cb1;
caey(up)=ca1;
cbey(up)=cb1;

caexzf(1,up)=ca1;    %interface between up and front     
cbexzf(1,up)=-cb1;         %cbexzf(1:iefbc,1:jebc,kebc+kb)=-cb1;  
caeyzf(1,up)=ca1;        
cbeyzf(1,up)=cb1;         %cbeyzf(1:ibfbc,1:jebc,kebc+kb)=cb1;  

caexzb(1,up)=ca1;         %interface between up and back
cbexzb(1,up)=-cb1;         %cbexzb(1:iefbc,1:jbbc,kebc+kb)=-cb1; 
caeyzb(1,up)=ca1;
cbeyzb(1,up)=cb1;         %cbeyzb(1:ibfbc,1:jebc,kebc+kb)=cb1; 

caexzl(1,up)=ca1;     %interface between up and left
cbexzl(1,up)=-cb1;         %cbexzl(1:iebc,1:jb,kebc+kb)=-cb1;
caeyzl(1,up)=ca1;
cbeyzl(1,up)=cb1;         %cbeyzl(1:iebc,1:je,kebc+kb)=cb1; 
  
caexzr(1,up)=ca1;     %interface between up and right
cbexzr(1,up)=-cb1;         %cbexzr(1:iebc,1:jb,kebc+kb)=-cb1; 
caeyzr(1,up)=ca1;
cbeyzr(1,up)=cb1;         %cbeyzr(1:ibbc,1:je,kebc+kb)=cb1;  

for k=1:kebc
  z1=k*dx;
  z2=(k-1)*dx;
  sigmak=bcfactor*(z1^(orderbc+1)-z2^(orderbc+1));
  sigmaks=sigmak*(muz/(epsz*eps(1)));
  da1=exp(-sigmaks*dt/muz);
  db1=(1-da1)/(sigmaks*dx);

  dahxzu(k)=da1;         %dahxzu(1:ib,1:je,k)=da1;
  dbhxzu(k)=db1;
  dahyzu(k)=da1;         % dahyzu(1:ie,1:jb,k)=da1; 
  dbhyzu(k)=-db1;

  dahxzf(k,up)=da1;           %region between down and front 
  dbhxzf(k,up)=db1;         %dbhxzf(1:ibfbc,1:jebc,k+kebc+ke)=db1;
  dahyzf(k,up)=da1;
  dbhyzf(k,up)=-db1;         %dbhyzf(1:iefbc,1:jebc,k+kebc+ke)=-db1;
  
  dahxzb(k,up)=da1;           %region between down and back
  dbhxzb(k,up)=db1;           %
  dahyzb(k,up)=da1;           %dahyzb(1:iefbc,1:jbbc,k+kebc+ke)=da1; 
  dbhyzb(k,up)=-db1;
  
  dahxzl(k,up)=da1;              %region between down and left
  dbhxzl(k,up)=db1;
  dahyzl(k,up)=da1;              %  dahyzl(1:iebc,1:jb,k+kebc+ke)=da1;
  dbhyzl(k,up)=-db1;
  
  dahxzr(k,up)=da1;              %region between down and right
  dbhxzr(k,up)=db1;
  dahyzr(k,up)=da1;               %dahyzr(1:iebc,1:jb,k+kebc+ke)=da1;   
  dbhyzr(k,up)=-db1;
  
end

%***********************************************************************
%     movie initialization
%***********************************************************************

tview(:,:)=ez(:,:,2);
sview(:,:)=ez(:,2,:);

figure(1);
subplot('position',[0.1 0.5 0.7 0.4]),pcolor((tview'));
shading flat;
%caxis([-4.0, 0])
colorbar;
axis image;
title([' Epower(xz plane), time step = ',timestep]);
%ylabel('y coordinate');

subplot('position',[0.1 0.05 0.7 0.35]),pcolor((sview'));
shading flat;
%caxis([-4.0, 0])
colorbar;
axis image;
title(['Epower(yz plane), time step = ',timestep]);

rect=get(gcf,'Position');
rect(1:2)=[0 0];
M=moviein(nmax,gcf,rect);
%***********************************************************************
%     BEGIN TIME-STEPPING LOOP
%***********************************************************************

for n=1:nmax
    n
%***********************************************************************
%     E field
%***********************************************************************
for m=1:ie                        %the whole main grid
flag=0;                            
flagx=0;
ii=m-iw;
      if (m<=iw)|(m>iw+io)     %1--iw&iw+2TX--ie
        flagx=1;                %outside the object domain
      end
    
      if (m<=iw)|(m>iw+io+1)    %2--iw&iw+2TX--ie
        flag=1;                %outside the object domain
      end
  
   for l=1:je
       flag1x=0;
       flag1y=0;
       flag1z=0;
       jj=l-jw;
       if flagx==0             %        -------ex field
            if (l<=jw)|(l>jw+jo+1)
                 flag1x=1;
            end
        end     
        if flag==0             %        -------ey field
             if (l<=jw)|(l>jw+jo)
                 flag1y=1;
             end
        end    
        if flag==0               %      -------ez field
             if (l<=jw)|(l>jw+jo+1)
                 flag1z=1;
             end
        end

            for  k=1:ke
                kk=k-kw;   
                if flagx|flag1x|(k<=kw)|(k>kw+ko+1)
                     if (l~=1)&(k~=1)
                            ex(m,l,k)=ca(1)*ex(m,l,k)+cb(1)*(hz(m,l,k)-hz(m,l-1,k)+...
                                                hy(m,l,k-1)-hy(m,l,k));
                      end
                else
                     if (l~=1)&(k~=1) 
                            ex(m,l,k)=ca(cx(ii,jj,kk))*ex(m,l,k)+cb(cx(ii,jj,kk))*(hz(m,l,k)-hz(m,l-1,k)+...
                                                hy(m,l,k-1)-hy(m,l,k)); 
                     end
                      if  (cx(ii,jj,kk)==metaly)|(cx(ii,jj,kk)==metalx)  % metaly means metal in y dir--Ex,Ez=0
                         ex(m, l, k)=0;
                      end 

                end
                                            
                 if flag|flag1y|(k<=kw)|(k>kw+ko)
                     if (m~=1)&(k~=1)
                            ey(m,l,k)=ca(1)*ey(m,l,k)+cb(1)*(hx(m,l,k)-hx(m,l,k-1)+...
                                                hz(m-1,l,k)-hz(m,l,k));
                      end
                  else  
                      if (m~=1)&(k~=1) 
                            ey(m,l,k)=ca(cy(ii,jj,kk))*ey(m,l,k)+cb(cy(ii,jj,kk))*(hx(m,l,k)-hx(m,l,k-1)+...
                                                hz(m-1,l,k)-hz(m,l,k)); 
                      end
                      if (cy(ii,jj,kk)==metaly)|(cy(ii,jj,kk)==metalx) %metalx means metal in x dir--Ey,Ez=0
                         ey(m, l, k)=0;
                      end  
                  end
                 
                if flag|flag1z|(k<=kw)|(k>kw+ko)
                          if (m~=1)&(l~=1)
                             ez(m,l,k)=ca(1)*ez(m,l,k)+cb(1)*(hx(m,l-1,k)-hx(m,l,k)+...
                                               hy(m,l,k)-hy(m-1,l,k));
                          end
                else
                    if (m~=1)&(l~=1)
                        ez(m,l,k)=ca(cz(ii,jj,kk))*ez(m,l,k)+cb(cz(ii,jj,kk))*(hx(m,l-1,k)-hx(m,l,k)+...
                                               hy(m,l,k)-hy(m-1,l,k));
                    end                      
                end
                
          end   %k
     end    %l
end      %m 


%***********************************************************************
%     Update EX in PML regions
%***********************************************************************

%     FRONT(surface Exf is 0,l=1; k=1&kbfbc)
for l=2:jebc
    exybcf(:,l,2:kefbc)=caexyf(l)*exybcf(:,l,2:kefbc)+...  
            cbexyf(l)*(hzxbcf(:,l,2:kefbc)+hzybcf(:,l,2:kefbc)-...
                           hzxbcf(:,l-1,2:kefbc)-hzybcf(:,l-1,2:kefbc));
                       
     for k=2:kbbc                                       %down--1 to kbbc in Z direction
         exzbcf(:,l,k)=caexzf(k,down)*exzbcf(:,l,k)+...  
            cbexzf(k,down)*(hyzbcf(:,l,k)+hyxbcf(:,l,k)-...
                      hyzbcf(:,l,k-1)-hyxbcf(:,l,k-1));
     end
     
     for k=kebc+2:kebc+ke                        %middle
         exzbcf(:,l,k)=ca(1)*exzbcf(:,l,k)-...  
            cb(1)*(hyzbcf(:,l,k)+hyxbcf(:,l,k)-hyzbcf(:,l,k-1)-hyxbcf(:,l,k-1));
     end
     
     for k=kbbc+ke: kefbc                         %up
         exzbcf(:,l,k)=caexzf(k-ke-kebc,up)*exzbcf(:,l,k)+...  
            cbexzf(k-kebc-ke,up)*(hyzbcf(:,l,k)+hyxbcf(:,l,k)-...
                      hyzbcf(:,l,k-1)-hyxbcf(:,l,k-1));
     end
  
end

ex(1:ie,1,1)=caex(front).*ex(1:ie,1,1)+...
  cbex(front).*(hz(1:ie,1,1)-hzxbcf(ibbc:iebc+ie,jebc,kbbc)-hzybcf(ibbc:iebc+ie,jebc,kbbc)+...
       hyxbcd(1:ie,1,kebc)+hyzbcd(1:ie,1,kebc)-hy(1:ie,1,1));
ex(1:ie,1,2:ke)=caex(front).*ex(1:ie,1,2:ke)+...
  cbex(front).*(hz(1:ie,1,2:ke)-...
    hzxbcf(ibbc:iebc+ie,jebc,kebc+2:kebc+ke)-hzybcf(ibbc:iebc+ie,jebc,kebc+2:kebc+ke)+...
    hy(1:ie,1,1:ke-1)-hy(1:ie,1,2:ke));
ex(1:ie,1,kb)=caex(front).*ex(1:ie,1,kb)+...
  cbex(front).*(hz(1:ie,1,kb)-hzxbcf(ibbc:iebc+ie,jebc,kebc+kb)-hzybcf(ibbc:iebc+ie,jebc,kebc+kb)+...
            hy(1:ie,1,ke)-hyxbcu(1:ie,1,1)-hyzbcu(1:ie,1,1));

                  %     BACK(surface Exb is 0,l=jbbc; k=1&kbfbc, andj=1 array is 0)
for l=2:jebc
    
    exybcb(:,l,2:kefbc)=caexyb(l)*exybcb(:,l,2:kefbc)+...  
        cbexyb(l)*(hzxbcb(:,l,2:kefbc)+hzybcb(:,l,2:kefbc)-...
                      hzxbcb(:,l-1,2:kefbc)-hzybcb(:,l-1,2:kefbc));
                  
     for k=2:kbbc                    % down--2 to kbbc in Z direction,ignor k=1
        exzbcb(:,l,k)=caexzb(k,down).*exzbcb(:,l,k)+...  
               cbexzb(k,down).*(hyzbcb(:,l,k)+hyxbcb(:,l,k)-...
                      hyzbcb(:,l,k-1)-hyxbcb(:,l,k-1));
     end
     
     for k=kebc+2:kebc+ke         % middle
        exzbcb(:,l,k)=ca(1).*exzbcb(:,l,k)-...  
               cb(1).*(hyzbcb(:,l,k)+hyxbcb(:,l,k)-hyzbcb(:,l,k-1)-hyxbcb(:,l,k-1));
     end
     
    for k=ke+kbbc:kefbc                    % up--1 to kebc in Z direction,ignor k=kbbc
        exzbcb(:,l,k)=caexzb(k-ke-kebc,up).*exzbcb(:,l,k)+...  
               cbexzb(k-ke-kebc,up).*(hyzbcb(:,l,k)+hyxbcb(:,l,k)-...
                      hyzbcb(:,l,k-1)-hyxbcb(:,l,k-1));
     end
 
end

ex(1:ie,jb,1)=caex(back).*ex(1:ie,jb,1)+...
  cbex(back).*(hzxbcb(ibbc:iebc+ie,1,kbbc)+hzybcb(ibbc:iebc+ie,1,kbbc)-hz(1:ie,je,1)+...
            hyxbcd(1:ie,jb,kebc)+hyzbcd(1:ie,jb,kebc)-hy(1:ie,jb,1));
ex(1:ie,jb,2:ke)=caex(back).*ex(1:ie,jb,2:ke)+...
  cbex(back).*(hzxbcb(ibbc:iebc+ie,1,kebc+2:kebc+ke)+hzybcb(ibbc:iebc+ie,1,kebc+2:kebc+ke)-hz(1:ie,je,2:ke)+...
           hy(1:ie,jb,1:ke-1)-hy(1:ie,jb,2:ke));
ex(1:ie,jb,kb)=caex(back).*ex(1:ie,jb,kb)+...
  cbex(back).*(hzxbcb(ibbc:iebc+ie,1,kbbc+ke)+hzybcb(ibbc:iebc+ie,1,kbbc+ke)-hz(1:ie,je,kb)+...
            hy(1:ie,jb,ke)-hyxbcu(1:ie,jb,1)-hyzbcu(1:ie,jb,1));

                  
%     LEFT(left and up/down suface is 0)
 
exybcl(:,2:je,2:kefbc)=ca(1).*exybcl(:,2:je,2:kefbc)+...
  cb(1).*(hzxbcl(:,2:je,2:kefbc)+hzybcl(:,2:je,2:kefbc)-...
                           hzxbcl(:,1:je-1,2:kefbc)-hzybcl(:,1:je-1,2:kefbc));
exybcl(:,1,2:kefbc)=caexyl(front).*exybcl(:,1,2:kefbc)+...
  cbexyl(front).*(hzxbcl(:,1,2:kefbc)+hzybcl(:,1,2:kefbc)-...
                         hzxbcf(1:iebc,jebc,2:kefbc)-hzybcf(1:iebc,jebc,2:kefbc));
exybcl(:,jb,2:kefbc)=caexyl(back).*exybcl(:,jb,2:kefbc)+...
  cbexyl(back).*(hzxbcb(1:iebc,1,2:kefbc)+hzybcb(1:iebc,1,2:kefbc)-...
                         hzxbcl(:,je,2:kefbc)-hzybcl(:,je,2:kefbc));
for k=2:kbbc
    exzbcl(:,1:jb,k)=caexzl(k,down).*exzbcl(:,1:jb,k)+...
            cbexzl(k,down).*(hyxbcl(:,1:jb,k)+hyzbcl(:,1:jb,k)-...
                           hyxbcl(:,1:jb,k-1)-hyzbcl(:,1:jb,k-1));
end

for k=kebc+2:kebc+ke 
    exzbcl(:,1:jb,k)=ca(1).*exzbcl(:,1:jb,k)-...
            cb(1).*(hyxbcl(:,1:jb,k)+hyzbcl(:,1:jb,k)-...
                           hyxbcl(:,1:jb,k-1)-hyzbcl(:,1:jb,k-1));
end

for k=ke+kbbc:kefbc  
     exzbcl(:,1:jb,k)=caexzl(k-ke-kebc,up).*exzbcl(:,1:jb,k)+...
            cbexzl(k-ke-kebc,up).*(hyxbcl(:,1:jb,k)+hyzbcl(:,1:jb,k)-...
                           hyxbcl(:,1:jb,k-1)-hyzbcl(:,1:jb,k-1));
end
 
%     RIGHT
exybcr(:,2:je,2:kefbc)=ca(1).*exybcr(:,2:je,2:kefbc)+...
  cb(1).*(hzxbcr(:,2:je,2:kefbc)+hzybcr(:,2:je,2:kefbc)-...
                           hzxbcr(:,1:je-1,2:kefbc)-hzybcr(:,1:je-1,2:kefbc));
exybcr(:,1,2:kefbc)=caexyr(front).*exybcr(:,1,2:kefbc)+...
  cbexyr(front).*(hzxbcr(:,1,2:kefbc)+hzybcr(:,1,2:kefbc)-...
                         hzxbcf(1+iebc+ie:iefbc,jebc,2:kefbc)-hzybcf(1+iebc+ie:iefbc,jebc,2:kefbc));
exybcr(:,jb,2:kefbc)=caexyr(back).*exybcr(:,jb,2:kefbc)+...
  cbexyr(back).*(hzxbcb(1+iebc+ie:iefbc,1,2:kefbc)+hzybcb(1+iebc+ie:iefbc,1,2:kefbc)-...
                         hzxbcr(:,je,2:kefbc)-hzybcr(:,je,2:kefbc));
for k=2:kbbc            %down
    exzbcr(:,1:jb,k)=caexzr(k,down).*exzbcr(:,1:jb,k)+...
        cbexzr(k,down)*(hyxbcr(:,1:jb,k)+hyzbcr(:,1:jb,k)-...
                           hyxbcr(:,1:jb,k-1)-hyzbcr(:,1:jb,k-1));
end

for k=kebc+2:kebc+ke 
     exzbcr(:,1:jb,k)=ca(1).*exzbcr(:,1:jb,k)-...
        cb(1)*(hyxbcr(:,1:jb,k)+hyzbcr(:,1:jb,k)-...
                           hyxbcr(:,1:jb,k-1)-hyzbcr(:,1:jb,k-1));
end

for k=ke+kbbc:kefbc  
     exzbcr(:,1:jb,k)=caexzr(k-ke-kebc,up).*exzbcr(:,1:jb,k)+...
        cbexzr(k-ke-kebc,up).*(hyxbcr(:,1:jb,k)+hyzbcr(:,1:jb,k)-...
                           hyxbcr(:,1:jb,k-1)-hyzbcr(:,1:jb,k-1));
end

              
%    DOWN
exybcd(:,2:je,2:kebc)=ca(1).*exybcd(:,2:je,2:kebc)+...
  cb(1).*(hzxbcd(:,2:je,2:kebc)+hzybcd(:,2:je,2:kebc)-...
                          hzxbcd(:,1:je-1,2:kebc)-hzybcd(:,1:je-1,2:kebc));
exybcd(:,1,2:kebc)=caexyd(front).*exybcd(:,1,2:kebc)+...
  cbexyd(front).*(hzxbcd(:,1,2:kebc)+hzybcd(:,1,2:kebc)-...
                       hzxbcf(ibbc:iebc+ie,jebc,2:kebc)-hzybcf(ibbc:iebc+ie,jebc,2:kebc));
exybcd(:,jb,2:kebc)=caexyd(back).*exybcd(:,jb,2:kebc)+...
  cbexyd(back).*(hzxbcb(ibbc:iebc+ie,1,2:kebc)+hzybcb(ibbc:iebc+ie,1,2:kebc)-...
                        hzxbcd(:,je,2:kebc)-hzybcd(:,je,2:kebc));
for k=2:kebc                    
        exzbcd(:,1:jb,k)=caexzd(k).*exzbcd(:,1:jb,k)+...
            cbexzd(k).*(hyxbcd(:,1:jb,k)+hyzbcd(:,1:jb,k)-...
                          hyxbcd(:,1:jb,k-1)-hyzbcd(:,1:jb,k-1));
end
ex(:,2:je,1)=caex(down).*ex(:,2:je,1)+cbex(down).*(hz(:,2:je,1)-hz(:,1:je-1,1)+...
   hyxbcd(:,2:je,kebc)+hyzbcd(:,2:je,kebc)-hy(:,2:je,1));
    
    %    UP
exybcu(:,2:je,2:kebc)=ca(1).*exybcu(:,2:je,2:kebc)+...
  cb(1).*(hzxbcu(:,2:je,2:kebc)+hzybcu(:,2:je,2:kebc)-...
                           hzxbcu(:,1:je-1,2:kebc)-hzybcu(:,1:je-1,2:kebc));
exybcu(:,1,2:kebc)=caexyu(front).*exybcu(:,1,2:kebc)+...          
  cbexyu(front).*(hzxbcu(:,1,2:kebc)+hzybcu(:,1,2:kebc)-...
          hzxbcf(ibbc:iebc+ie,jebc,ke+kebc+2:kefbc)-hzybcf(ibbc:iebc+ie,jebc,ke+kebc+2:kefbc));
exybcu(:,jb,2:kebc)=caexyu(back).*exybcu(:,jb,2:kebc)+...
  cbexyu(back).*(hzxbcb(ibbc:iebc+ie,1,ke+kebc+2:kefbc)+...
                                  hzybcb(ibbc:iebc+ie,1,ke+kebc+2:kefbc)-...
                         hzxbcu(:,je,2:kebc)-hzybcu(:,je,2:kebc));
for k=2:kebc                      
exzbcu(:,1:jb,k)=caexzu(k).*exzbcu(:,1:jb,k)+...
  cbexzu(k).*(hyxbcu(:,1:jb,k)+hyzbcu(:,1:jb,k)-...
                           hyxbcu(:,1:jb,k-1)-hyzbcu(:,1:jb,k-1));
end                       
ex(:,2:je,kb)=caex(up).*ex(:,2:je,kb)+ cbex(up).*(hz(:,2:je,kb)-hz(:,1:je-1,kb)+...
            hy(:,2:je,ke)-hyxbcu(:,2:je,1)-hyzbcu(:,2:je,1));
                       
                       
%***********************************************************************
%     Update Ey in PML regions
%***********************************************************************
%     FRONT(surface Eyf is 0,when m=1&ibfbc; k=1&kbfbc)
for m=2:ibbc                            %left m=2--ibbc
    eyxbcf(m,:,2:kefbc)=caeyxf(m,left).*eyxbcf(m,:,2:kefbc)+...  
            cbeyxf(m,left).*(hzxbcf(m,:,2:kefbc)+hzybcf(m,:,2:kefbc)-...
                      hzxbcf(m-1,:,2:kefbc)-hzybcf(m-1,:,2:kefbc));
end

for m=iebc+2:iebc+ie                 %middle
    eyxbcf(m,:,2:kefbc)=ca(1).*eyxbcf(m,:,2:kefbc)-...  
            cb(1).*(hzxbcf(m,:,2:kefbc)+hzybcf(m,:,2:kefbc)-...
                      hzxbcf(m-1,:,2:kefbc)-hzybcf(m-1,:,2:kefbc));
end

for m=iebc+ib:iefbc                     %right m=1--iebc
    eyxbcf(m,:,2:kefbc)=caeyxf(m-ie-iebc,right).*eyxbcf(m,:,2:kefbc)+...  
            cbeyxf(m-ie-iebc,right).*(hzxbcf(m,:,2:kefbc)+hzybcf(m,:,2:kefbc)-...
                      hzxbcf(m-1,:,2:kefbc)-hzybcf(m-1,:,2:kefbc));
end

for k=2:ibbc                           %down k=2:kbbc
    eyzbcf(2:iefbc,:,k)=caeyzf(k,down).*eyzbcf(2:iefbc,:,k)+...  
            cbeyzf(k,down).*(hxybcf(2:iefbc,:,k)+hxzbcf(2:iefbc,:,k)-...
                      hxybcf(2:iefbc,:,k-1)-hxzbcf(2:iefbc,:,k-1));
end
for k=kebc+2:kebc+ke            %middle
     eyzbcf(2:iefbc,:,k)=ca(1).*eyzbcf(2:iefbc,:,k)+...  
            cb(1).*(hxybcf(2:iefbc,:,k)+hxzbcf(2:iefbc,:,k)-...
                        hxybcf(2:iefbc,:,k-1)-hxzbcf(2:iefbc,:,k-1));
end
for k=kebc+kb:kefbc                %up
    eyzbcf(2:iefbc,:,k)=caeyzf(k-ke-kebc,up).*eyzbcf(2:iefbc,:,k)+...  
            cbeyzf(k-ke-kebc,up).*(hxybcf(2:iefbc,:,k)+hxzbcf(2:iefbc,:,k)-...
                      hxybcf(2:iefbc,:,k-1)-hxzbcf(2:iefbc,:,k-1));
end
%     BACK
for m=2:ibbc                            %left m=2--ibbc
    eyxbcb(m,:,2:kefbc)=caeyxb(m,left).*eyxbcb(m,:,2:kefbc)+...  
        cbeyxb(m,left).*(hzxbcb(m,:,2:kefbc)+hzybcb(m,:,2:kefbc)-...
                      hzxbcb(m-1,:,2:kefbc)-hzybcb(m-1,:,2:kefbc));
end
for m=iebc+2:iebc+ie                 %middle
     eyxbcb(m,:,2:kefbc)=ca(1).*eyxbcb(m,:,2:kefbc)-...  
        cb(1).*(hzxbcb(m,:,2:kefbc)+hzybcb(m,:,2:kefbc)-...
                      hzxbcb(m-1,:,2:kefbc)-hzybcb(m-1,:,2:kefbc));
end
for m=iebc+ib:iefbc                     %right m=1--iebc
     eyxbcb(m,:,2:kefbc)=caeyxb(m-iebc-ie,right).*eyxbcb(m,:,2:kefbc)+...  
        cbeyxb(m-iebc-ie,right).*(hzxbcb(m,:,2:kefbc)+hzybcb(m,:,2:kefbc)-...
                      hzxbcb(m-1,:,2:kefbc)-hzybcb(m-1,:,2:kefbc));
end
for k=2:ibbc                           %down k=2:kbbc
    eyzbcb(2:iefbc,:,k)=caeyzb(k,down).*eyzbcb(2:iefbc,:,k)+...  
        cbeyzb(k,down).*(hxybcb(2:iefbc,:,k)+hxzbcb(2:iefbc,:,k)-...
                      hxybcb(2:iefbc,:,k-1)-hxzbcb(2:iefbc,:,k-1));
end
for k=kebc+2:kebc+ke            %middle
    eyzbcb(2:iefbc,:,k)=ca(1).*eyzbcb(2:iefbc,:,k)+...  
        cb(1).*(hxybcb(2:iefbc,:,k)+hxzbcb(2:iefbc,:,k)-...
                      hxybcb(2:iefbc,:,k-1)-hxzbcb(2:iefbc,:,k-1));
end
for k=kebc+kb:kefbc                %up
    eyzbcb(2:iefbc,:,k)=caeyzb(k-kebc-ke,up).*eyzbcb(2:iefbc,:,k)+...  
        cbeyzb(k-kebc-ke,up).*(hxybcb(2:iefbc,:,k)+hxzbcb(2:iefbc,:,k)-...
                      hxybcb(2:iefbc,:,k-1)-hxzbcb(2:iefbc,:,k-1));
end
%     LEFT
for m=2:iebc                            
    eyxbcl(m,:,2:kefbc)=caeyxl(m).*eyxbcl(m,:,2:kefbc)+...
        cbeyxl(m).*(hzxbcl(m,:,2:kefbc)+hzybcl(m,:,2:kefbc)-...
                      hzxbcl(m-1,:,2:kefbc)-hzybcl(m-1,:,2:kefbc));
end
for k=2:ibbc                           %down k=2:kbbc
     eyzbcl(2:iebc,:,k)=caeyzl(k,down).*eyzbcl(2:iebc,:,k)+...
        cbeyzl(k,down).*(hxybcl(2:iebc,:,k)+hxzbcl(2:iebc,:,k)-...
                      hxybcl(2:iebc,:,k-1)-hxzbcl(2:iebc,:,k-1));
end

for k=kebc+2:kebc+ke            %middle
     eyzbcl(2:iebc,:,k)=ca(1).*eyzbcl(2:iebc,:,k)+...
        cb(1).*(hxybcl(2:iebc,:,k)+hxzbcl(2:iebc,:,k)-...
                      hxybcl(2:iebc,:,k-1)-hxzbcl(2:iebc,:,k-1));
end

for k=kebc+kb:kefbc                %up
     eyzbcl(2:iebc,:,k)=caeyzl(k-kebc-ke,up).*eyzbcl(2:iebc,:,k)+...
        cbeyzl(k-kebc-ke,up).*(hxybcl(2:iebc,:,k)+hxzbcl(2:iebc,:,k)-...
                      hxybcl(2:iebc,:,k-1)-hxzbcl(2:iebc,:,k-1));
end

ey(1,1:je,1)=caey(left).*ey(1,1:je,1)+...
    cbey(left).*(hx(1,1:je,1)-hxybcd(1,1:je,kebc)-hxzbcd(1,1:je,kebc)+...
                           hzxbcl(iebc,1:je,kbbc)+hzybcl(iebc,1:je,kbbc)-hz(1,1:je,1));
                       
ey(1,1:je,2:ke)=caey(left).*ey(1,1:je,2:ke)+...
  cbey(left).*(hx(1,1:je,2:ke)-hx(1,1:je,1:ke-1)-hz(1,1:je,2:ke)+...
                             hzxbcl(iebc,1:je,kebc+2:kebc+ke)+hzybcl(iebc,1:je,kebc+2:kebc+ke));
                        
ey(1,1:je,kb)=caey(left).*ey(1,1:je,kb)+...
  cbey(left).*(hxybcu(1,1:je,1)+hxzbcu(1,1:je,1)-hx(1,1:je,ke)+...
                hzxbcl(iebc,1:je,kbbc+ke)+hzybcl(iebc,1:je,kbbc+ke)-hz(1,1:je,kb));

%     RIGHT
for m=2:iebc        
    eyxbcr(m,:,2:kefbc)=caeyxr(m).*eyxbcr(m,:,2:kefbc)+...
           cbeyxr(m).*(hzxbcr(m,:,2:kefbc)+hzybcr(m,:,2:kefbc)-...
                                            hzxbcr(m-1,:,2:kefbc)-hzybcr(m-1,:,2:kefbc));
end
for k=2:ibbc                           %down k=2:kbbc
     eyzbcr(2:iebc,:,k)=caeyzr(k,down).*eyzbcr(2:iebc,:,k)+...
            cbeyzr(k,down).*(hxybcr(2:iebc,:,k)+hxzbcr(2:iebc,:,k)-...
                      hxybcr(2:iebc,:,k-1)-hxzbcr(2:iebc,:,k-1));
end

for k=kebc+2:kebc+ke            %middle
    eyzbcr(2:iebc,:,k)=ca(1).*eyzbcr(2:iebc,:,k)+...
            cb(1).*(hxybcr(2:iebc,:,k)+hxzbcr(2:iebc,:,k)-...
                      hxybcr(2:iebc,:,k-1)-hxzbcr(2:iebc,:,k-1));
end

for k=kebc+kb:kefbc                %up
     eyzbcr(2:iebc,:,k)=caeyzr(k-kebc-ke,up).*eyzbcr(2:iebc,:,k)+...
            cbeyzr(k-kebc-ke,up).*(hxybcr(2:iebc,:,k)+hxzbcr(2:iebc,:,k)-...
                      hxybcr(2:iebc,:,k-1)-hxzbcr(2:iebc,:,k-1));
end
ey(ib,1:je,1)=caey(right).*ey(ib,1:je,1)+...
  cbey(right).*(hx(ib,1:je,1)-hxybcd(ib,1:je,kebc)-hxzbcd(ib,1:je,kebc)+...
        hz(ie,1:je,1)-hzxbcr(1,1:je,kbbc)-hzybcr(1,1:je,kbbc));

ey(ib,1:je,2:ke)=caey(right).*ey(ib,1:je,2:ke)+...
  cbey(right).*(hx(ib,1:je,2:ke)-hx(ib,1:je,1:ke-1)+hz(ie,1:je,2:ke)-...
            hzxbcr(1,1:je,kebc+2:kebc+ke)-hzybcr(1,1:je,kebc+2:kebc+ke));

ey(ib,1:je,kb)=caey(right).*ey(ib,1:je,kb)+...
  cbey(right).*(hxybcu(ib,1:je,1)+hxzbcu(ib,1:je,1)-hx(ib,1:je,ke)+hz(ie,1:je,kb)-...
            hzxbcr(1,1:je,kebc+kb)-hzybcr(1,1:je,kebc+kb));



%	DOWN
eyxbcd(2:ie,:,2:kebc)=ca(1).*eyxbcd(2:ie,:,2:kebc)-...
  cb(1).*(hzxbcd(2:ie,:,2:kebc)+hzybcd(2:ie,:,2:kebc)-...
                          hzxbcd(1:ie-1,:,2:kebc)-hzybcd(1:ie-1,:,2:kebc));
eyxbcd(1,:,2:kebc)=caeyxd(left).*eyxbcd(1,:,2:kebc)+...
  cbeyxd(left).*(hzxbcd(1,:,2:kebc)+hzybcd(1,:,2:kebc)-...
                       hzxbcl(iebc,1:je,2:kebc)-hzybcl(iebc,1:je,2:kebc));
eyxbcd(ib,:,2:kebc)=caeyxd(right).*eyxbcd(ib,:,2:kebc)+...
  cbeyxd(right).*(hzxbcr(1,1:je,2:kebc)+hzybcr(1,1:je,2:kebc)-...
                        hzxbcd(ie,:,2:kebc)-hzybcd(ie,:,2:kebc));
for k=2:kebc                    
     eyzbcd(1:ib,:,k)=caeyzd(k).*eyzbcd(1:ib,:,k)+...
            cbeyzd(k).*(hxybcd(1:ib,:,k)+hxzbcd(1:ib,:,k)-...
                          hxybcd(1:ib,:,k-1)-hxzbcd(1:ib,:,k-1));
end
ey(2:ie,:,1)=caey(down).*ey(2:ie,:,1)+...
    cbey(down).*(hx(2:ie,:,1)-hxybcd(2:ie,:,kebc)-hxzbcd(2:ie,:,kebc)+...
            hz(1:ie-1,:,1)-hz(2:ie,:,1));

                     %    UP
eyxbcu(2:ie,:,2:kebc)=ca(1).*eyxbcu(2:ie,:,2:kebc)-...
  cb(1).*(hzxbcu(2:ie,:,2:kebc)+hzybcu(2:ie,:,2:kebc)-...
                          hzxbcu(1:ie-1,:,2:kebc)-hzybcu(1:ie-1,:,2:kebc));
eyxbcu(1,:,2:kebc)=caeyxu(left).*eyxbcu(1,:,2:kebc)+...
  cbeyxu(left).*(hzxbcu(1,:,2:kebc)+hzybcu(1,:,2:kebc)-...
                       hzxbcl(iebc,:,ke+kebc+2:kefbc)-hzybcl(iebc,:,ke+kebc+2:kefbc));
eyxbcu(ib,:,2:kebc)=caeyxu(right).*eyxbcu(ib,:,2:kebc)+...
  cbeyxu(right).*(hzxbcr(1,:,ke+kebc+2:kefbc)+hzybcr(1,:,ke+kebc+2:kefbc)-...
                        hzxbcu(ie,:,2:kebc)-hzybcu(ie,:,2:kebc));
for k=2:kebc   
    eyzbcu(1:ib,:,k)=caeyzu(k).*eyzbcu(1:ib,:,k)+...
         cbeyzu(k).*(hxybcu(1:ib,:,k)+hxzbcu(1:ib,:,k)-...
                          hxybcu(1:ib,:,k-1)-hxzbcu(1:ib,:,k-1));
end
ey(2:ie,:,kb)=caey(up).*ey(2:ie,:,kb)+...
    cbey(up).*(hxybcu(2:ie,:,1)+hxzbcu(2:ie,:,1)-hx(2:ie,:,ke)+...
            hz(1:ie-1,:,kb)-hz(2:ie,:,kb));

%***********************************************************************
%     Update EZ in PML regions
%***********************************************************************
 
%     FRONT(surface Ezf is 0,when m=1&ibfbc; l=1&jbbc)
for m=2:ibbc                             %left m=2--ibbc
    ezxbcf(m,2:jebc,:)=caezxf(m,left)*ezxbcf(m,2:jebc,:)+...  
        cbezxf(m,left)*(hyxbcf(m,2:jebc,:)+hyzbcf(m,2:jebc,:)-...
                      hyxbcf(m-1,2:jebc,:)-hyzbcf(m-1,2:jebc,:));
end
 
for m=iebc+2:iebc+ie                  %middle
    ezxbcf(m,2:jebc,:)=ca(1).*ezxbcf(m,2:jebc,:)+...  
           cb(1).*(hyxbcf(m,2:jebc,:)+hyzbcf(m,2:jebc,:)-...
                      hyxbcf(m-1,2:jebc,:)-hyzbcf(m-1,2:jebc,:));
end

for m=iebc+ib:iefbc                     %right m=1--iebc
    ezxbcf(m,2:jebc,:)=caezxf(m-iebc-ie,right).*ezxbcf(m,2:jebc,:)+...  
           cbezxf(m-iebc-ie,right).*(hyxbcf(m,2:jebc,:)+hyzbcf(m,2:jebc,:)-...
                      hyxbcf(m-1,2:jebc,:)-hyzbcf(m-1,2:jebc,:));
end

for l=2:jebc
    ezybcf(2:iefbc,l,:)=caezyf(l).*ezybcf(2:iefbc,l,:)+...  
            cbezyf(l).*(hxybcf(2:iefbc,l,:)+hxzbcf(2:iefbc,l,:)-...
                      hxybcf(2:iefbc,l-1,:)-hxzbcf(2:iefbc,l-1,:));
end
                  
ez(2:ie,1,:)=caez(front).*ez(2:ie,1,:)+cbez(front).*(hy(2:ie,1,:)-hy(1:ie-1,1,:)+...
      hxybcf(iebc+2:iebc+ie,jebc,kebc+1:kebc+ke)+...
               hxzbcf(iebc+2:iebc+ie,jebc,kebc+1:kebc+ke)-hx(2:ie,1,:));
ez(1,1,1:ke)=caez(front).*ez(1,1,1:ke)+...
  cbez(front).*(hy(1,1,1:ke)-hyxbcl(iebc,1,kbbc:kebc+ke)-hyzbcl(iebc,1,kbbc:kebc+ke)+...
           hxybcf(ibbc,jebc,kbbc:kebc+ke)+hxzbcf(ibbc,jebc,kbbc:kebc+ke)-hx(1,1,1:ke));               
ez(ib,1,:)=caez(front).*ez(ib,1,:)+...
  cbez(front).*(hyxbcr(1,1,kbbc:kebc+ke)+hyzbcr(1,1,kbbc:kebc+ke)-hy(ie,1,1:ke)+...
    hxybcf(ie+ibbc,jebc,kbbc:kebc+ke)+hxzbcf(ie+ibbc,jebc,kbbc:kebc+ke)-hx(ib,1,1:ke));
  
  %     BACK
for m=2:ibbc                             %left m=2--ibbc
        ezxbcb(m,2:jebc,:)=caezxb(m,left).*ezxbcb(m,2:jebc,:)+...  
               cbezxb(m,left).*(hyxbcb(m,2:jebc,:)+hyzbcb(m,2:jebc,:)-...
                                 hyxbcb(m-1,2:jebc,:)-hyzbcb(m-1,2:jebc,:));
end
 
for m=iebc+2:iebc+ie                  %middle
      ezxbcb(m,2:jebc,:)=ca(1).*ezxbcb(m,2:jebc,:)+...  
               cb(1).*(hyxbcb(m,2:jebc,:)+hyzbcb(m,2:jebc,:)-...
                                 hyxbcb(m-1,2:jebc,:)-hyzbcb(m-1,2:jebc,:));
end   

for m=iebc+ib:iefbc                     %right m=1--iebc
        ezxbcb(m,2:jebc,:)=caezxb(m-iebc-ie,right).*ezxbcb(m,2:jebc,:)+...  
               cbezxb(m-iebc-ie,right).*(hyxbcb(m,2:jebc,:)+hyzbcb(m,2:jebc,:)-...
                                 hyxbcb(m-1,2:jebc,:)-hyzbcb(m-1,2:jebc,:));
end

for l=2:jebc
       ezybcb(2:iefbc,l,:)=caezyb(l).*ezybcb(2:iefbc,l,:)+...  
                cbezyb(l).*(hxybcb(2:iefbc,l,:)+hxzbcb(2:iefbc,l,:)-...
                      hxybcb(2:iefbc,l-1,:)-hxzbcb(2:iefbc,l-1,:));
end

ez(2:ie,jb,:)=caez(back).*ez(2:ie,jb,:)+cbex(back).*(hy(2:ie,jb,:)-hy(1:ie-1,jb,:)+...
      hx(2:ie,je,:)-hxybcb(iebc+2:ie+iebc,1,kebc+1:kebc+ke)-...
      hxzbcb(iebc+2:ie+iebc,1,kebc+1:kebc+ke));
ez(1,jb,1:ke)=caez(back).*ez(1,jb,1:ke)+...
  cbez(back).*(hy(1,jb,1:ke)-hyxbcl(iebc,jb,kbbc:kebc+ke)-hyzbcl(iebc,jb,kbbc:kebc+ke)+...
		hx(1,je,1:ke)-hxybcb(ibbc,1,kbbc:kebc+ke)-hxzbcb(ibbc,1,kbbc:kebc+ke));
ez(ib,jb,1:ke)=caez(back).*ez(ib,jb,1:ke)+...
  cbez(back).*(hyxbcr(1,jb,kbbc:kebc+ke)+hyzbcr(1,jb,kbbc:kebc+ke)-hy(ie,jb,1:ke)+...
       hx(ib,je,1:ke)-hxybcb(ie+ibbc,1,kbbc:kebc+ke)-hxzbcb(ie+ibbc,1,kbbc:kebc+ke));

   %     LEFT
for m=2:iebc
     ezxbcl(m,1:jb,:)=caezxl(m).*ezxbcl(m,1:jb,:)+...  
            cbezxl(m).*(hyxbcl(m,1:jb,:)+hyzbcl(m,1:jb,:)-...
                      hyxbcl(m-1,1:jb,:)-hyzbcl(m-1,1:jb,:));
end

ezybcl(2:iebc,2:je,:)=ca(1).*ezybcl(2:iebc,2:je,:)-... 
        cb(1).*(hxybcl(2:iebc,2:je,:)+hxzbcl(2:iebc,2:je,:)-...
                      hxybcl(2:iebc,1:je-1,:)-hxzbcl(2:iebc,1:je-1,:));
ezybcl(2:iebc,1,:)=caezyl(front).*ezybcl(2:iebc,1,:)+...  
  cbezyl(front).*(hxybcl(2:iebc,1,:)+hxzbcl(2:iebc,1,:)-...
                      hxybcf(2:iebc,jebc,:)-hxzbcf(2:iebc,jebc,:));
ezybcl(2:iebc,jb,:)=caezyl(back).*ezybcl(2:iebc,jb,:)+...  
  cbezyl(back).*(hxybcb(2:iebc,1,:)+hxzbcb(2:iebc,1,:)-...
                      hxybcl(2:iebc,je,:)-hxzbcl(2:iebc,je,:));
ez(1,2:je,1:ke)=caez(left).*ez(1,2:je,1:ke)+...
  cbez(left).*(hy(1,2:je,1:ke)-hyxbcl(iebc,2:je,kbbc:kebc+ke)-hyzbcl(iebc,2:je,kbbc:kebc+ke)+...
    hx(1,1:je-1,1:ke)-hx(1,2:je,1:ke));
                  
    %       Right
for m=2:iebc
        ezxbcr(m,1:jb,:)=caezxr(m).*ezxbcr(m,1:jb,:)+...  
            cbezxr(m).*(hyxbcr(m,1:jb,:)+hyzbcr(m,1:jb,:)-...
                      hyxbcr(m-1,1:jb,:)-hyzbcr(m-1,1:jb,:));
end
ezybcr(2:iebc,1,:)=caezyr(front).*ezybcr(2:iebc,1,:)+...  
  cbezyr(front).*(hxybcr(2:iebc,1,:)+hxzbcr(2:iebc,1,:)-...
                      hxybcf(2+ie+iebc:iefbc,jebc,:)-hxzbcf(2+ie+iebc:iefbc,jebc,:));
ezybcr(2:iebc,2:je,:)=ca(1).*ezybcr(2:iebc,2:je,:)-...  
  cb(1).*(hxybcr(2:iebc,2:je,:)+hxzbcr(2:iebc,2:je,:)-...
                      hxybcr(2:iebc,1:je-1,:)-hxzbcr(2:iebc,1:je-1,:));
ezybcr(2:iebc,jb,:)=caezyr(back).*ezybcr(2:iebc,jb,:)+...  
  cbezyr(back).*(hxybcb(2+ie+iebc:iefbc,1,:)+hxzbcb(2+ie+iebc:iefbc,1,:)-...
                      hxybcr(2:iebc,je,:)-hxzbcr(2:iebc,je,:));
ez(ib,2:je,:)=caez(right).*ez(ib,2:je,:)+...
  cbez(right).*(hyxbcr(1,2:je,kbbc:kebc+ke)+hyzbcr(1,2:je,kbbc:kebc+ke)-hy(ie,2:je,1:ke)+...
    hx(ib,1:je-1,1:ke)-hx(ib,2:je,1:ke));
                   
   %    Down
                                        
ezxbcd(1,1:jb,:)=caezxd(left).*ezxbcd(1,1:jb,:)+...  
  cbezxd(left).*(hyxbcd(1,1:jb,:)+hyzbcd(1,1:jb,:)-...
                      hyxbcl(iebc,1:jb,1:kebc)-hyzbcl(iebc,1:jb,1:kebc));
ezxbcd(2:ie,1:jb,:)=ca(1).*ezxbcd(2:ie,1:jb,:)+...  
  cb(1).*(hyxbcd(2:ie,1:jb,:)+hyzbcd(2:ie,1:jb,:)-...
                      hyxbcd(1:ie-1,1:jb,:)-hyzbcd(1:ie-1,1:jb,:));
ezxbcd(ib,1:jb,:)=caezxd(right).*ezxbcd(ib,1:jb,:)+...  
  cbezxd(right).*(hyxbcr(1,1:jb,1:kebc)+hyzbcr(1,1:jb,1:kebc)-...
                             hyxbcd(ie,1:jb,:)-hyzbcd(ie,1:jb,:));
                         
ezybcd(1:ib,1,:)=caezyd(front).*ezybcd(1:ib,1,:)+...  
  cbezyd(front).*(hxybcd(1:ib,1,:)+hxzbcd(1:ib,1,:)-...
                            hxybcf(ibbc:iebc+ib,jebc,1:kebc)-hxzbcf(ibbc:iebc+ib,jebc,1:kebc));
ezybcd(1:ib,2:je,:)=ca(1).*ezybcd(1:ib,2:je,:)-...  
  cb(1).*(hxybcd(1:ib,2:je,:)+hxzbcd(1:ib,2:je,:)-...
                                hxybcd(1:ib,1:je-1,:)-hxzbcd(1:ib,1:je-1,:));
ezybcd(1:ib,jb,:)=caezyd(back).*ezybcd(1:ib,jb,:)+...  
  cbezyd(back).*(hxybcb(ibbc:iebc+ib,1,1:kebc)+hxzbcb(ibbc:iebc+ib,1,1:kebc)-...
                             hxybcd(1:ib,je,:)-hxzbcd(1:ib,je,:));
                
%    UP

ezxbcu(1,1:jb,:)=caezxu(left).*ezxbcu(1,1:jb,:)+...  
  cbezxu(left).*(hyxbcu(1,1:jb,:)+hyzbcu(1,1:jb,:)-...
                      hyxbcl(iebc,1:jb,ke+kbbc:kefbc)-hyzbcl(iebc,1:jb,ke+kbbc:kefbc));
ezxbcu(2:ie,1:jb,:)=ca(1).*ezxbcu(2:ie,1:jb,:)+...  
  cb(1).*(hyxbcu(2:ie,1:jb,:)+hyzbcu(2:ie,1:jb,:)-...
                      hyxbcu(1:ie-1,1:jb,:)-hyzbcu(1:ie-1,1:jb,:));
ezxbcu(ib,1:jb,:)=caezxu(right).*ezxbcu(ib,1:jb,:)+...  
  cbezxu(right).*(hyxbcr(1,1:jb,ke+kbbc:kefbc)+hyzbcr(1,1:jb,ke+kbbc:kefbc)-...
                             hyxbcu(ie,1:jb,:)-hyzbcu(ie,1:jb,:));
                         
ezybcu(1:ib,1,:)=caezyu(front).*ezybcu(1:ib,1,:)+...  
  cbezyu(front).*(hxybcu(1:ib,1,:)+hxzbcu(1:ib,1,:)-...
                            hxybcf(ibbc:iebc+ib,jebc,ke+kbbc:kefbc)-hxzbcf(ibbc:iebc+ib,jebc,ke+kbbc:kefbc));
ezybcu(1:ib,2:je,:)=ca(1).*ezybcu(1:ib,2:je,:)-...  
  cb(1).*(hxybcu(1:ib,2:je,:)+hxzbcu(1:ib,2:je,:)-...
                                hxybcu(1:ib,1:je-1,:)-hxzbcu(1:ib,1:je-1,:));
ezybcu(1:ib,jb,:)=caezyu(back).*ezybcu(1:ib,jb,:)+...  
  cbezyu(back).*(hxybcb(ibbc:iebc+ib,1,ke+kbbc:kefbc)+hxzbcb(ibbc:iebc+ib,1,ke+kbbc:kefbc)-...
                             hxybcu(1:ib,je,:)-hxzbcu(1:ib,je,:));
                

%***********************************************************************
%     Update magnetic fields (H) in main grid
%***********************************************************************

hx(1:ib,1:je,1:ke)=da(1)*hx(1:ib,1:je,1:ke)+...
                   db(1)*(ey(1:ib,1:je,2:kb)-ey(1:ib,1:je,1:ke)+...
                       ez(1:ib,1:je,1:ke)-ez(1:ib,2:jb,1:ke));
                
hy(1:ie,1:jb,1:ke)=da(1)*hy(1:ie,1:jb,1:ke)+...
                   db(1)*(ex(1:ie,1:jb,1:ke)-ex(1:ie,1:jb,2:kb)+...
                       ez(2:ib,1:jb,1:ke)-ez(1:ie,1:jb,1:ke));
                
hz(1:ie,1:je,1:kb)=da(1)*hz(1:ie,1:je,1:kb)+...
                   db(1)*(ex(1:ie,2:jb,1:kb)-ex(1:ie,1:je,1:kb)+...
                       ey(1:ie,1:je,1:kb)-ey(2:ib,1:je,1:kb));
                   
for m=1:ie                        %the whole main grid  just the current and then specify the hx and hy
  ii=m-iw;
  if (ii>0)&(ii<size(cy,1))
      
        for l=1:je
            jj=l-jw;
            if (jj>0)&(jj<size(cx,2))
                
                for  k=1:ke
                    kk=k-kw;   
                    if (kk>0)&(kk<size(cx,3))
                        
                        if cx(ii,jj, kk)==metaly
                            hx(m, l, k)=1e-2*sin(omega*n*dt);
                        end
                        
                         if cy(ii,jj, kk)==metaly
                            hy(m, l, k)=1e-2*sin(omega*n*dt);
                         end
                        
                    end  %endifk
                end  %endk
                
            end  %endifj
        end  %endj
        
   end   %endif
end      %m 
%***********************************************************************
%     Update HX in PML regions
%***********************************************************************

%     FRONT
for l=1:jebc-1
    hxybcf(2:iefbc,l,1:kefbc)=dahxyf(l).*hxybcf(2:iefbc,l,1:kefbc)+...
            dbhxyf(l).*(ezxbcf(2:iefbc,l+1,1:kefbc)+ezybcf(2:iefbc,l+1,1:kefbc)-...
                                      ezxbcf(2:iefbc,l,1:kefbc)-ezybcf(2:iefbc,l,1:kefbc));
end
                                  
hxybcf(2:iebc,jebc,1:kefbc)=dahxyf(jebc).*hxybcf(2:iebc,jebc,1:kefbc)+...
    dbhxyf(jebc).*(ezxbcl(2:iebc,1,1:kefbc)+ezybcl(2:iebc,1,1:kefbc)-...
                                                   ezxbcf(2:iebc,jebc,1:kefbc)-ezybcf(2:iebc,jebc,1:kefbc));
hxybcf(ibbc:ie+ibbc,jebc,1:kebc)=dahxyf(jebc).*hxybcf(ibbc:ie+ibbc,jebc,1:kebc)+...
    dbhxyf(jebc).*(ezxbcd(1:ib,1,1:kebc)+ezybcd(1:ib,1,1:kebc)-...
                                                   ezxbcf(ibbc:ie+ibbc,jebc,1:kebc)-ezybcf(ibbc:ie+ibbc,jebc,1:kebc));
                                               
hxybcf(ibbc:ie+ibbc,jebc,kbbc:ke+kebc)=...
    dahxyf(jebc).*hxybcf(ibbc:ie+ibbc,jebc,kbbc:ke+kebc)+...
    dbhxyf(jebc).*(ez(1:ib,1,1:ke)-...
         ezxbcf(ibbc:ie+ibbc,jebc,kbbc:ke+kebc)-ezybcf(ibbc:ie+ibbc,jebc,kbbc:ke+kebc));
     
hxybcf(ibbc:ie+ibbc,jebc,ke+kbbc:kefbc)=...
    dahxyf(jebc).*hxybcf(ibbc:ie+ibbc,jebc,ke+kbbc:kefbc)+...
    dbhxyf(jebc).*(ezxbcu(1:ib,1,1:kebc)+ezybcu(1:ib,1,1:kebc)-...
        ezxbcf(ibbc:ie+ibbc,jebc,ke+kbbc:kefbc)-ezybcf(ibbc:ie+ibbc,jebc,ke+kbbc:kefbc));
hxybcf(ie+ibbc+1:iefbc,jebc,1:kefbc)=...
    dahxyf(jebc).*hxybcf(ie+ibbc+1:iefbc,jebc,1:kefbc)+...
    dbhxyf(jebc).*(ezxbcr(2:iebc,1,1:kefbc)+ezybcr(2:iebc,1,1:kefbc)-...
       ezxbcf(ie+ibbc+1:iefbc,jebc,1:kefbc)-ezybcf(ie+ibbc+1:iefbc,jebc,1:kefbc));

for k=1:kebc                               %down
    hxzbcf(2:iefbc,1:jebc,k)=dahxzf(k,down).*hxzbcf(2:iefbc,1:jebc,k)+...
            dbhxzf(k,down).*(eyzbcf(2:iefbc,1:jebc,k+1)+eyxbcf(2:iefbc,1:jebc,k+1)-...
                                                   eyzbcf(2:iefbc,1:jebc,k)-eyxbcf(2:iefbc,1:jebc,k));
end
for k=kebc+1:kebc+ke                %middle
    hxzbcf(2:iefbc,1:jebc,k)=da(1).*hxzbcf(2:iefbc,1:jebc,k)+...
            db(1).*(eyzbcf(2:iefbc,1:jebc,k+1)+eyxbcf(2:iefbc,1:jebc,k+1)-...
                                                   eyzbcf(2:iefbc,1:jebc,k)-eyxbcf(2:iefbc,1:jebc,k));
end
for k=kebc+kb:kefbc                %up
    hxzbcf(2:iefbc,1:jebc,k)=dahxzf(k-kebc-ke,up).*hxzbcf(2:iefbc,1:jebc,k)+...
            dbhxzf(k-kebc-ke,up).*(eyzbcf(2:iefbc,1:jebc,k+1)+eyxbcf(2:iefbc,1:jebc,k+1)-...
                                                   eyzbcf(2:iefbc,1:jebc,k)-eyxbcf(2:iefbc,1:jebc,k));
end
          
%     BACK
for l=2:jebc
hxybcb(2:iefbc,l,1:kefbc)=dahxyb(l).*hxybcb(2:iefbc,l,1:kefbc)+...
    dbhxyb(l).*(ezxbcb(2:iefbc,l+1,1:kefbc)+ezybcb(2:iefbc,l+1,1:kefbc)-...
                                                   ezxbcb(2:iefbc,l,1:kefbc)-ezybcb(2:iefbc,l,1:kefbc));
end

hxybcb(2:iebc,1,1:kefbc)=dahxyb(1).*hxybcb(2:iebc,1,1:kefbc)+...
    dbhxyb(1).*(ezxbcb(2:iebc,2,1:kefbc)+ezybcb(2:iebc,2,1:kefbc)-...
                                            ezxbcl(2:iebc,jb,1:kefbc)-ezybcl(2:iebc,jb,1:kefbc));
%when l=1, ezxb=0                                             
hxybcb(ibbc:ie+ibbc,1,1:kebc)=dahxyb(1).*hxybcb(ibbc:ie+ibbc,1,1:kebc)+...
    dbhxyb(1).*(ezxbcb(ibbc:ie+ibbc,2,1:kebc)+ezybcb(ibbc:ie+ibbc,2,1:kebc)-...
                                                        ezxbcd(1:ib,jb,1:kebc)-ezybcd(1:ib,jb,1:kebc));
hxybcb(ibbc:ie+ibbc,1,kbbc:ke+kebc)=...
    dahxyb(1).*hxybcb(ibbc:ie+ibbc,1,kbbc:ke+kebc)+...
    dbhxyb(1).*(-ez(1:ib,jb,1:ke)+...
            ezxbcb(ibbc:ie+ibbc,2,kbbc:ke+kebc)+ezybcb(ibbc:ie+ibbc,2,kbbc:ke+kebc));

hxybcb(ibbc:ie+ibbc,1,ke+kbbc:kefbc)=...
    dahxyb(1).*hxybcb(ibbc:ie+ibbc,1,ke+kbbc:kefbc)+...
    dbhxyb(1).*(ezxbcb(ibbc:ie+ibbc,2,ke+kbbc:kefbc)+ezybcb(ibbc:ie+ibbc,2,ke+kbbc:kefbc)-...
       ezxbcu(1:ib,jb,1:kebc)-ezybcu(1:ib,jb,1:kebc));
   
hxybcb(ie+ibbc+1:iefbc,1,1:kefbc)=...
    dahxyb(1).*hxybcb(ie+ibbc+1:iefbc,1,1:kefbc)+...
    dbhxyb(1).*(ezxbcb(ie+ibbc+1:iefbc,2,1:kefbc)+ezybcb(ie+ibbc+1:iefbc,2,1:kefbc)-...
      ezxbcr(2:iebc,jb,1:kefbc)-ezybcr(2:iebc,jb,1:kefbc));
for k=1:kebc                               %down
    hxzbcb(2:iefbc,1:jebc,k)=dahxzb(k,down).*hxzbcb(2:iefbc,1:jebc,k)+...
            dbhxzb(k,down).*(eyzbcb(2:iefbc,1:jebc,k+1)+eyxbcb(2:iefbc,1:jebc,k+1)-...
                                                   eyzbcb(2:iefbc,1:jebc,k)-eyxbcb(2:iefbc,1:jebc,k));
end
for k=kebc+1:kebc+ke                %middle
    hxzbcb(2:iefbc,1:jebc,k)=da(1).*hxzbcb(2:iefbc,1:jebc,k)+...
            db(1).*(eyzbcb(2:iefbc,1:jebc,k+1)+eyxbcb(2:iefbc,1:jebc,k+1)-...
                                                   eyzbcb(2:iefbc,1:jebc,k)-eyxbcb(2:iefbc,1:jebc,k));
end
for k=kebc+kb:kefbc                %up
    hxzbcb(2:iefbc,1:jebc,k)=dahxzb(k-kebc-ke,up).*hxzbcb(2:iefbc,1:jebc,k)+...
            dbhxzb(k-kebc-ke,up).*(eyzbcb(2:iefbc,1:jebc,k+1)+eyxbcb(2:iefbc,1:jebc,k+1)-...
                                                   eyzbcb(2:iefbc,1:jebc,k)-eyxbcb(2:iefbc,1:jebc,k));
end

%     LEFT
hxybcl(2:iebc,1:je,1:kefbc)=da(1).*hxybcl(2:iebc,1:je,1:kefbc)-...
    db(1).*(ezxbcl(2:iebc,2:jb,1:kefbc)+ezybcl(2:iebc,2:jb,1:kefbc)-...
                                                   ezxbcl(2:iebc,1:je,1:kefbc)-ezybcl(2:iebc,1:je,1:kefbc));
for k=1:kebc                               %down
    hxzbcl(2:iebc,1:je,k)=dahxzl(k,down).*hxzbcl(2:iebc,1:je,k)+...
        dbhxzl(k,down).*(eyxbcl(2:iebc,1:je,k+1)+eyzbcl(2:iebc,1:je,k+1)-...
                                                   eyxbcl(2:iebc,1:je,k)-eyzbcl(2:iebc,1:je,k));
end
for k=kebc+1:kebc+ke                %middle
    hxzbcl(2:iebc,1:je,k)=da(1).*hxzbcl(2:iebc,1:je,k)+...
        db(1).*(eyxbcl(2:iebc,1:je,k+1)+eyzbcl(2:iebc,1:je,k+1)-...
                                                   eyxbcl(2:iebc,1:je,k)-eyzbcl(2:iebc,1:je,k));
end
for k=kebc+kb:kefbc                %up
    hxzbcl(2:iebc,1:je,k)=dahxzl(k-kebc-ke,up).*hxzbcl(2:iebc,1:je,k)+...
        dbhxzl(k-kebc-ke,up).*(eyxbcl(2:iebc,1:je,k+1)+eyzbcl(2:iebc,1:je,k+1)-...
                                                   eyxbcl(2:iebc,1:je,k)-eyzbcl(2:iebc,1:je,k));
end

%     RIGHT
hxybcr(2:iebc,1:je,1:kefbc)=da(1).*hxybcr(2:iebc,1:je,1:kefbc)-...
    db(1).*(ezxbcr(2:iebc,2:jb,1:kefbc)+ezybcr(2:iebc,2:jb,1:kefbc)-...
               ezxbcr(2:iebc,1:je,1:kefbc)-ezybcr(2:iebc,1:je,1:kefbc));
for k=1:kebc                               %down
    hxzbcr(2:iebc,1:je,k)=dahxzr(k,down).*hxzbcr(2:iebc,1:je,k)+...
            dbhxzr(k,down).*(eyxbcr(2:iebc,1:je,k+1)+eyzbcr(2:iebc,1:je,k+1)-...
                                                   eyxbcr(2:iebc,1:je,k)-eyzbcr(2:iebc,1:je,k));
end
for k=kebc+1:kebc+ke                %middle
    hxzbcr(2:iebc,1:je,k)=da(1).*hxzbcr(2:iebc,1:je,k)+...
            db(1).*(eyxbcr(2:iebc,1:je,k+1)+eyzbcr(2:iebc,1:je,k+1)-...
                                                   eyxbcr(2:iebc,1:je,k)-eyzbcr(2:iebc,1:je,k));
end
for k=kebc+kb:kefbc                %up
    hxzbcr(2:iebc,1:je,k)=dahxzr(k-kebc-ke,up).*hxzbcr(2:iebc,1:je,k)+...
            dbhxzr(k-kebc-ke,up).*(eyxbcr(2:iebc,1:je,k+1)+eyzbcr(2:iebc,1:je,k+1)-...
                                                   eyxbcr(2:iebc,1:je,k)-eyzbcr(2:iebc,1:je,k));
end
           
%H is same as E, in right region, m=0 array is meanless, then their coordinates are same                                               

%     DOWN
hxybcd(1:ib,1:je,1:kebc)=da(1).*hxybcd(1:ib,1:je,1:kebc)-...
    db(1).*(ezxbcd(1:ib,2:jb,1:kebc)+ezybcd(1:ib,2:jb,1:kebc)-...
                                                   ezxbcd(1:ib,1:je,1:kebc)-ezybcd(1:ib,1:je,1:kebc));
for k=1:kebc-1                                               
hxzbcd(1:ib,1:je,k)=dahxzd(k).*hxzbcd(1:ib,1:je,k)+...
    dbhxzd(k).*(eyxbcd(1:ib,1:je,k+1)+eyzbcd(1:ib,1:je,k+1)-...
                                                   eyxbcd(1:ib,1:je,k)-eyzbcd(1:ib,1:je,k));
end
hxzbcd(1:ib,1:je,kebc)=dahxzd(kebc).*hxzbcd(1:ib,1:je,kebc)+...
    dbhxzd(kebc).*(ey(1:ib,1:je,1)-eyxbcd(1:ib,1:je,kebc)-eyzbcd(1:ib,1:je,kebc));

%     UP
hxybcu(1:ib,1:je,1:kebc)=da(1).*hxybcu(1:ib,1:je,1:kebc)-...
    db(1).*(ezxbcu(1:ib,2:jb,1:kebc)+ezybcu(1:ib,2:jb,1:kebc)-...
                                                   ezxbcu(1:ib,1:je,1:kebc)-ezybcu(1:ib,1:je,1:kebc));
for k=2:kebc                                               
    hxzbcu(1:ib,1:je,k)=dahxzu(k).*hxzbcu(1:ib,1:je,k)+...
        dbhxzu(k).*(eyxbcu(1:ib,1:je,k+1)+eyzbcu(1:ib,1:je,k+1)-...
                                                   eyxbcu(1:ib,1:je,k)-eyzbcu(1:ib,1:je,k));
end
hxzbcu(1:ib,1:je,1)=dahxzu(1).*hxzbcu(1:ib,1:je,1)+...
    dbhxzu(1).*(eyxbcu(1:ib,1:je,2)+eyzbcu(1:ib,1:je,2)-ey(1:ib,1:je,kb));

%***********************************************************************
%     Update Hy in PML regions
%***********************************************************************

%     FRONT
for k=1:kebc                        %down
    hyzbcf(1:iefbc,2:jebc,k)=dahyzf(k,down).*hyzbcf(1:iefbc,2:jebc,k)+...
            dbhyzf(k,down).*(exybcf(1:iefbc,2:jebc,k+1)+exzbcf(1:iefbc,2:jebc,k+1)-...
                                                   exybcf(1:iefbc,2:jebc,k)-exzbcf(1:iefbc,2:jebc,k));
end
for k=kbbc:kebc+ke             %middle
    hyzbcf(1:iefbc,2:jebc,k)=da(1).*hyzbcf(1:iefbc,2:jebc,k)-...
            db(1).*(exybcf(1:iefbc,2:jebc,k+1)+exzbcf(1:iefbc,2:jebc,k+1)-...
                                                   exybcf(1:iefbc,2:jebc,k)-exzbcf(1:iefbc,2:jebc,k));
end
for k=kebc+kb:kefbc             %up
    hyzbcf(1:iefbc,2:jebc,k)=dahyzf(k-kebc-ke,up).*hyzbcf(1:iefbc,2:jebc,k)+...
            dbhyzf(k-kebc-ke,up).*(exybcf(1:iefbc,2:jebc,k+1)+exzbcf(1:iefbc,2:jebc,k+1)-...
                                                   exybcf(1:iefbc,2:jebc,k)-exzbcf(1:iefbc,2:jebc,k));
end

for m=1:iebc                           %left
    hyxbcf(m,2:jebc,1:kefbc)=dahyxf(m,left).*hyxbcf(m,2:jebc,1:kefbc)+...
            dbhyxf(m,left).*(ezxbcf(m+1,2:jebc,1:kefbc)+ezybcf(m+1,2:jebc,1:kefbc)-...
                                                   ezxbcf(m,2:jebc,1:kefbc)-ezybcf(m,2:jebc,1:kefbc));
end
for m=ibbc:iebc+ie                           %middle
    hyxbcf(m,2:jebc,1:kefbc)=da(1).*hyxbcf(m,2:jebc,1:kefbc)+...
            db(1).*(ezxbcf(m+1,2:jebc,1:kefbc)+ezybcf(m+1,2:jebc,1:kefbc)-...
                                                   ezxbcf(m,2:jebc,1:kefbc)-ezybcf(m,2:jebc,1:kefbc));
end
for m=iebc+ib:iefbc                         %right
    hyxbcf(m,2:jebc,1:kefbc)=dahyxf(m-iebc-ie,right).*hyxbcf(m,2:jebc,1:kefbc)+...
            dbhyxf(m-iebc-ie,right).*(ezxbcf(m+1,2:jebc,1:kefbc)+ezybcf(m+1,2:jebc,1:kefbc)-...
                                                   ezxbcf(m,2:jebc,1:kefbc)-ezybcf(m,2:jebc,1:kefbc));
end

%     BACK
for k=1:kebc                        %down
    hyzbcb(1:iefbc,2:jebc,k)=dahyzb(k,down).*hyzbcb(1:iefbc,2:jebc,k)+...
            dbhyzb(k,down).*(exybcb(1:iefbc,2:jebc,k+1)+exzbcb(1:iefbc,2:jebc,k+1)-...
                                                   exybcb(1:iefbc,2:jebc,k)-exzbcb(1:iefbc,2:jebc,k));
end
for k=kbbc:kebc+ke             %middle
    hyzbcb(1:iefbc,2:jebc,k)=da(1).*hyzbcb(1:iefbc,2:jebc,k)-...
            db(1).*(exybcb(1:iefbc,2:jebc,k+1)+exzbcb(1:iefbc,2:jebc,k+1)-...
                                                   exybcb(1:iefbc,2:jebc,k)-exzbcb(1:iefbc,2:jebc,k));
end
for k=kebc+kb:kefbc             %up
    hyzbcb(1:iefbc,2:jebc,k)=dahyzb(k-kebc-ke,up).*hyzbcb(1:iefbc,2:jebc,k)+...
            dbhyzb(k-kebc-ke,up).*(exybcb(1:iefbc,2:jebc,k+1)+exzbcb(1:iefbc,2:jebc,k+1)-...
                                                   exybcb(1:iefbc,2:jebc,k)-exzbcb(1:iefbc,2:jebc,k));
end
for m=1:iebc                           %left
    hyxbcb(m,2:jebc,1:kefbc)=dahyxb(m,left).*hyxbcb(m,2:jebc,1:kefbc)+...
            dbhyxb(m,left).*(ezxbcb(m+1,2:jebc,1:kefbc)+ezybcb(m+1,2:jebc,1:kefbc)-...
                                                   ezxbcb(m,2:jebc,1:kefbc)-ezybcb(m,2:jebc,1:kefbc));
end
for m=ibbc:iebc+ie                           %middle
    hyxbcb(m,2:jebc,1:kefbc)=da(1).*hyxbcb(m,2:jebc,1:kefbc)+...
            db(1).*(ezxbcb(m+1,2:jebc,1:kefbc)+ezybcb(m+1,2:jebc,1:kefbc)-...
                                                   ezxbcb(m,2:jebc,1:kefbc)-ezybcb(m,2:jebc,1:kefbc));
end
for m=iebc+ib:iefbc                         %right
    hyxbcb(m,2:jebc,1:kefbc)=dahyxb(m-iebc-ie,right).*hyxbcb(m,2:jebc,1:kefbc)+...
            dbhyxb(m-iebc-ie,right).*(ezxbcb(m+1,2:jebc,1:kefbc)+ezybcb(m+1,2:jebc,1:kefbc)-...
                                                   ezxbcb(m,2:jebc,1:kefbc)-ezybcb(m,2:jebc,1:kefbc));
end

%     LEFT
for k=1:kebc                        %down
    hyzbcl(1:iebc,1:jb,k)=dahyzl(k,down).*hyzbcl(1:iebc,1:jb,k)+...
            dbhyzl(k,down).*(exybcl(1:iebc,1:jb,k+1)+exzbcl(1:iebc,1:jb,k+1)-...
                                                   exybcl(1:iebc,1:jb,k)-exzbcl(1:iebc,1:jb,k));
end
for k=kbbc:kebc+ke
    hyzbcl(1:iebc,1:jb,k)=da(1).*hyzbcl(1:iebc,1:jb,k)-...
            db(1).*(exybcl(1:iebc,1:jb,k+1)+exzbcl(1:iebc,1:jb,k+1)-...
                                                   exybcl(1:iebc,1:jb,k)-exzbcl(1:iebc,1:jb,k));
end
for k=kebc+kb:kefbc
    hyzbcl(1:iebc,1:jb,k)=dahyzl(k-kebc-ke,up).*hyzbcl(1:iebc,1:jb,k)+...
            dbhyzl(k-kebc-ke,up).*(exybcl(1:iebc,1:jb,k+1)+exzbcl(1:iebc,1:jb,k+1)-...
                                                   exybcl(1:iebc,1:jb,k)-exzbcl(1:iebc,1:jb,k));
end
for m=1:iebc-1
hyxbcl(m,1:jb,1:kefbc)=dahyxl(m).*hyxbcl(m,1:jb,1:kefbc)+...
    dbhyxl(m).*(ezxbcl(m+1,1:jb,1:kefbc)+ezybcl(m+1,1:jb,1:kefbc)-...
                    ezxbcl(m,1:jb,1:kefbc)-ezybcl(m,1:jb,1:kefbc));
end                                     
hyxbcl(iebc,1:jb,1:kebc)=dahyxl(iebc).*hyxbcl(iebc,1:jb,1:kebc)+...
    dbhyxl(iebc).*(ezxbcd(1,1:jb,1:kebc)+ezybcd(1,1:jb,1:kebc)-...
                                          ezxbcl(iebc,1:jb,1:kebc)-ezybcl(iebc,1:jb,1:kebc));

hyxbcl(iebc,1:jb,kbbc+ke:kefbc)=dahyxl(iebc).*hyxbcl(iebc,1:jb,kbbc+ke:kefbc)+...
    dbhyxl(iebc).*(ezxbcu(1,1:jb,1:kebc)+ezybcu(1,1:jb,1:kebc)-...
                                                   ezxbcl(iebc,1:jb,kbbc+ke:kefbc)-ezybcl(iebc,1:jb,kbbc+ke:kefbc));
hyxbcl(iebc,1:jb,kbbc:ke+kebc)=dahyxl(iebc).*hyxbcl(iebc,1:jb,kbbc:ke+kebc)+...
    dbhyxl(iebc).*(ez(1,1:jb,1:ke)-...
                                                   ezxbcl(iebc,1:jb,kbbc:ke+kebc)-ezybcl(iebc,1:jb,kbbc:ke+kebc));
  %     Right 
for k=1:kebc                        %down
    hyzbcr(1:iebc,1:jb,k)=dahyzr(k,down).*hyzbcr(1:iebc,1:jb,k)+...
            dbhyzr(k,down).*(exybcr(1:iebc,1:jb,k+1)+exzbcr(1:iebc,1:jb,k+1)-...
                                      exybcr(1:iebc,1:jb,k)-exzbcr(1:iebc,1:jb,k));
end
for k=kbbc:kebc+ke
    hyzbcr(1:iebc,1:jb,k)=da(1).*hyzbcr(1:iebc,1:jb,k)-...
            db(1).*(exybcr(1:iebc,1:jb,k+1)+exzbcr(1:iebc,1:jb,k+1)-...
                                      exybcr(1:iebc,1:jb,k)-exzbcr(1:iebc,1:jb,k));
end
for k=kebc+kb:kefbc
    hyzbcr(1:iebc,1:jb,k)=dahyzr(k-kebc-ke,up).*hyzbcr(1:iebc,1:jb,k)+...
            dbhyzr(k-kebc-ke,up).*(exybcr(1:iebc,1:jb,k+1)+exzbcr(1:iebc,1:jb,k+1)-...
                                      exybcr(1:iebc,1:jb,k)-exzbcr(1:iebc,1:jb,k));
end

for m=2:iebc
hyxbcr(m,1:jb,1:kefbc)=dahyxr(m).*hyxbcr(m,1:jb,1:kefbc)+...
    dbhyxr(m).*(ezxbcr(m+1,1:jb,1:kefbc)+ezybcr(m+1,1:jb,1:kefbc)-...
                    ezxbcr(m,1:jb,1:kefbc)-ezybcr(m,1:jb,1:kefbc));
end
hyxbcr(1,1:jb,1:kebc)=dahyxr(1).*hyxbcr(1,1:jb,1:kebc)+...
    dbhyxr(1).*(ezxbcr(2,1:jb,1:kebc)+ezybcr(2,1:jb,1:kebc)-...
                                        ezxbcd(ib,1:jb,1:kebc)-ezybcd(ib,1:jb,1:kebc));
                                    
hyxbcr(1,1:jb,kbbc+ke:kefbc)=dahyxr(1).*hyxbcr(1,1:jb,kbbc+ke:kefbc)+...
    dbhyxr(1).*(ezxbcr(2,1:jb,kbbc+ke:kefbc)+ezybcr(2,1:jb,kbbc+ke:kefbc)-...
                                                    ezxbcu(ib,1:jb,1:kebc)-ezybcu(ib,1:jb,1:kebc));
hyxbcr(1,1:jb,kbbc:ke+kebc)=dahyxr(1).*hyxbcr(1,1:jb,kbbc:ke+kebc)+...
    dbhyxr(1).*(ezxbcr(2,1:jb,kbbc:ke+kebc)+ezybcr(2,1:jb,kbbc:ke+kebc)-...
                                                     ez(ib,1:jb,1:ke));

% Down
 hyxbcd(1:ie,1:jb,1:kebc)=da(1)*hyxbcd(1:ie,1:jb,1:kebc)+...
    db(1)*(ezxbcd(2:ib,1:jb,1:kebc)+ezybcd(2:ib,1:jb,1:kebc)-...
                ezxbcd(1:ie,1:jb,1:kebc)-ezybcd(1:ie,1:jb,1:kebc));
for k=1:kebc-1           
hyzbcd(1:ie,1:jb,k)=dahyzd(k)*hyzbcd(1:ie,1:jb,k)+...
    dbhyzd(k)*(exybcd(1:ie,1:jb,k+1)+exzbcd(1:ie,1:jb,k+1)-...
                                                   exybcd(1:ie,1:jb,k)-exzbcd(1:ie,1:jb,k));
end
hyzbcd(1:ie,1:jb,kebc)=dahyzd(kebc)*hyzbcd(1:ie,1:jb,kebc)+...
    dbhyzd(kebc)*(ex(1:ie,1:jb,1)-exybcd(1:ie,1:jb,kebc)-exzbcd(1:ie,1:jb,kebc));

% Up
 hyxbcu(1:ie,1:jb,1:kebc)=da(1)*hyxbcu(1:ie,1:jb,1:kebc)+...
    db(1)*(ezxbcu(2:ib,1:jb,1:kebc)+ezybcu(2:ib,1:jb,1:kebc)-...
                                                   ezxbcu(1:ie,1:jb,1:kebc)-ezybcu(1:ie,1:jb,1:kebc));
for k=2:kebc           
hyzbcu(1:ie,1:jb,k)=dahyzu(k)*hyzbcu(1:ie,1:jb,k)+...
    dbhyzu(k)*(exybcu(1:ie,1:jb,k+1)+exzbcu(1:ie,1:jb,k+1)-...
                     exybcu(1:ie,1:jb,k)-exzbcu(1:ie,1:jb,k));
end
hyzbcu(1:ie,1:jb,1)=dahyzu(1)*hyzbcu(1:ie,1:jb,1)+...
    dbhyzu(1)*(exybcu(1:ie,1:jb,2)+exzbcu(1:ie,1:jb,2)-ex(1:ie,1:jb,kb));

%***********************************************************************
%     Update HZ in PML regions
%***********************************************************************

%     FRONT(k=1&kbfbc, hz=0)
for m=1:iebc
    hzxbcf(m,:,2:kefbc)=dahzxf(m,left)*hzxbcf(m,:,2:kefbc)+...
           dbhzxf(m,left)*(eyxbcf(m+1,:,2:kefbc)+eyzbcf(m+1,:,2:kefbc)-...
                   eyxbcf(m,:,2:kefbc)-eyzbcf(m,:,2:kefbc));
end
for m=ibbc:ie+iebc
    hzxbcf(m,:,2:kefbc)=da(1)*hzxbcf(m,:,2:kefbc)-...
           db(1)*(eyxbcf(m+1,:,2:kefbc)+eyzbcf(m+1,:,2:kefbc)-...
                   eyxbcf(m,:,2:kefbc)-eyzbcf(m,:,2:kefbc));
end
for m=ie+ibbc:iefbc
    hzxbcf(m,:,2:kefbc)=dahzxf(m-ie-iebc,right)*hzxbcf(m,:,2:kefbc)+...
           dbhzxf(m-ie-iebc,right)*(eyxbcf(m+1,:,2:kefbc)+eyzbcf(m+1,:,2:kefbc)-...
                   eyxbcf(m,:,2:kefbc)-eyzbcf(m,:,2:kefbc));
end

for l=1:jebc-1
hzybcf(:,l,2:kefbc)=dahzyf(l)*hzybcf(:,l,2:kefbc)+...
  dbhzyf(l)*(exybcf(:,l+1,2:kefbc)+exzbcf(:,l+1,2:kefbc)-...
                          exybcf(:,l,2:kefbc)-exzbcf(:,l,2:kefbc));
end
hzybcf(1:iebc,jebc,2:kefbc)=dahzyf(jebc).*hzybcf(1:iebc,jebc,2:kefbc)+...
  dbhzyf(jebc).*(exybcl(1:iebc,1,2:kefbc)+exzbcl(1:iebc,1,2:kefbc)-...
                           exybcf(1:iebc,jebc,2:kefbc)-exzbcf(1:iebc,jebc,2:kefbc));
                       
hzybcf(ibbc:iebc+ie,jebc,2:kebc)=...
  dahzyf(jebc).*hzybcf(ibbc:iebc+ie,jebc,2:kebc)+...
  dbhzyf(jebc).*(exybcd(1:ie,1,2:kebc)+exzbcd(1:ie,1,2:kebc)-...
      exybcf(ibbc:iebc+ie,jebc,2:kebc)-exzbcf(ibbc:iebc+ie,jebc,2:kebc));
hzybcf(ibbc:iebc+ie,jebc,kbbc:kb+kebc)=...
  dahzyf(jebc).*hzybcf(ibbc:iebc+ie,jebc,kbbc:kb+kebc)+...
  dbhzyf(jebc).*(ex(1:ie,1,1:kb)-...
      exybcf(ibbc:iebc+ie,jebc,kbbc:kb+kebc)-exzbcf(ibbc:iebc+ie,jebc,kbbc:kb+kebc));
hzybcf(ibbc:iebc+ie,jebc,kb+kbbc:kefbc)=...
  dahzyf(jebc).*hzybcf(ibbc:iebc+ie,jebc,kb+kbbc:kefbc)+...
  dbhzyf(jebc).*(exybcu(1:ie,1,2:kebc)+exzbcu(1:ie,1,2:kebc)-...
            exybcf(ibbc:iebc+ie,jebc,kb+kbbc:kefbc)-exzbcf(ibbc:iebc+ie,jebc,kb+kbbc:kefbc));

hzybcf(iebc+ib:iefbc,jebc,2:kefbc)=...
  dahzyf(jebc).*hzybcf(iebc+ib:iefbc,jebc,2:kefbc)+...
  dbhzyf(jebc).*(exybcr(1:iebc,1,2:kefbc)+exzbcr(1:iebc,1,2:kefbc)-...
                           exybcf(iebc+ib:iefbc,jebc,2:kefbc)-exzbcf(iebc+ib:iefbc,jebc,2:kefbc));
                       
                       
%     BACK
for m=1:iebc
    hzxbcb(m,:,2:kefbc)=dahzxb(m,left)*hzxbcb(m,:,2:kefbc)+...
        dbhzxb(m,left)*(eyxbcb(m+1,:,2:kefbc)+eyzbcb(m+1,:,2:kefbc)-...
                   eyxbcb(m,:,2:kefbc)-eyzbcb(m,:,2:kefbc));
end
for m=ibbc:ie+iebc
    hzxbcb(m,:,2:kefbc)=da(1)*hzxbcb(m,:,2:kefbc)-...
        db(1)*(eyxbcb(m+1,:,2:kefbc)+eyzbcb(m+1,:,2:kefbc)-...
                   eyxbcb(m,:,2:kefbc)-eyzbcb(m,:,2:kefbc));
end
for m=ie+ibbc:iefbc
    hzxbcb(m,:,2:kefbc)=dahzxb(m-ie-iebc,right)*hzxbcb(m,:,2:kefbc)+...
        dbhzxb(m-ie-iebc,right)*(eyxbcb(m+1,:,2:kefbc)+eyzbcb(m+1,:,2:kefbc)-...
                   eyxbcb(m,:,2:kefbc)-eyzbcb(m,:,2:kefbc));
end
for l=2:jebc
hzybcb(:,l,2:kefbc)=dahzyb(l)*hzybcb(:,l,2:kefbc)+...
  dbhzyb(l)*(exybcb(:,l+1,2:kefbc)+exzbcb(:,l+1,2:kefbc)-...
                          exybcb(:,l,2:kefbc)-exzbcb(:,l,2:kefbc));
end
hzybcb(1:iebc,1,2:kefbc)=dahzyb(1)*hzybcb(1:iebc,1,2:kefbc)+...
  dbhzyb(1)*(exybcb(1:iebc,2,2:kefbc)+exzbcb(1:iebc,2,2:kefbc)-...
                    exybcl(1:iebc,jb,2:kefbc)-exzbcl(1:iebc,jb,2:kefbc));
                       
hzybcb(ibbc:iebc+ie,1,2:kebc)=...
  dahzyb(1)*hzybcb(ibbc:iebc+ie,1,2:kebc)+...
  dbhzyb(1)*(exybcb(ibbc:iebc+ie,2,2:kebc)+exzbcb(ibbc:iebc+ie,2,2:kebc)-...
                 exybcd(1:ie,jb,2:kebc)-exzbcd(1:ie,jb,2:kebc));

hzybcb(ibbc:iebc+ie,1,kb+kbbc:kefbc)=...
  dahzyb(1)*hzybcb(ibbc:iebc+ie,1,kb+kbbc:kefbc)+...
  dbhzyb(1)*(exybcb(ibbc:iebc+ie,2,kb+kbbc:kefbc)+exzbcb(ibbc:iebc+ie,2,kb+kbbc:kefbc)-...
        exybcu(1:ie,jb,2:kebc)-exzbcu(1:ie,jb,2:kebc));

hzybcb(iebc+ib:iefbc,1,2:kefbc)=...
  dahzyb(1)*hzybcb(iebc+ib:iefbc,1,2:kefbc)+...
  dbhzyb(1)*(exybcb(iebc+ib:iefbc,2,2:kefbc)+exzbcb(iebc+ib:iefbc,2,2:kefbc)-...
                       exybcr(1:iebc,jb,2:kefbc)-exzbcr(1:iebc,jb,2:kefbc));
                   
hzybcb(ibbc:iebc+ie,1,kbbc:kb+kebc)=...
  dahzyb(1)*hzybcb(ibbc:iebc+ie,1,kbbc:kb+kebc)+...
  dbhzyb(1)*(-ex(1:ie,jb,1:kb)+...
      exybcb(ibbc:iebc+ie,2,kbbc:kb+kebc)+exzbcb(ibbc:iebc+ie,2,kbbc:kb+kebc));
  

%     LEFT
for m=1:iebc-1 
    hzxbcl(m,:,2:kefbc)=dahzxl(m).*hzxbcl(m,:,2:kefbc)+...
        dbhzxl(m).*(eyxbcl(m+1,:,2:kefbc)+eyzbcl(m+1,:,2:kefbc)-...
            eyxbcl(m,:,2:kefbc)-eyzbcl(m,:,2:kefbc));
end

hzxbcl(iebc,:,2:kebc)=dahzxl(iebc).*hzxbcl(iebc,:,2:kebc)+...
  dbhzxl(iebc).*(eyxbcd(1,:,2:kebc)+eyzbcd(1,:,2:kebc)-...
            eyxbcl(iebc,:,2:kebc)-eyzbcl(iebc,:,2:kebc));
        
hzxbcl(iebc,:,kbbc:kb+kebc)=dahzxl(iebc).*hzxbcl(iebc,:,kbbc:kb+kebc)+...
  dbhzxl(iebc).*(ey(1,:,1:kb)-...
            eyxbcl(iebc,:,kbbc:kb+kebc)-eyzbcl(iebc,:,kbbc:kb+kebc));

hzxbcl(iebc,:,kb+kbbc:kefbc)=dahzxl(iebc).*hzxbcl(iebc,:,kb+kbbc:kefbc)+...
  dbhzxl(iebc).*(eyxbcu(1,:,2:kebc)+eyzbcu(1,:,2:kebc)-...
            eyxbcl(iebc,:,kb+kbbc:kefbc)-eyzbcl(iebc,:,kb+kbbc:kefbc));

hzybcl(:,1:je,2:kefbc)=da(1).*hzybcl(:,1:je,2:kefbc)+...
  db(1).*(exybcl(:,2:jb,2:kefbc)+exzbcl(:,2:jb,2:kefbc)-...
            exybcl(:,1:je,2:kefbc)-exzbcl(:,1:je,2:kefbc));
 
%     RIGHT
for m=2:iebc 
    hzxbcr(m,:,2:kefbc)=dahzxr(m).*hzxbcr(m,:,2:kefbc)+...        
        dbhzxr(m).*(eyzbcr(m+1,:,2:kefbc)+eyxbcr(m+1,:,2:kefbc)-...
            eyzbcr(m,:,2:kefbc)-eyxbcr(m,:,2:kefbc));
end
hzxbcr(1,:,2:kebc)=dahzxr(1)*hzxbcr(1,:,2:kebc)+...
    dbhzxr(1)*(eyzbcr(2,:,2:kebc)+eyxbcr(2,:,2:kebc)-...
        eyzbcd(ib,:,2:kebc)-eyxbcd(ib,:,2:kebc));
hzxbcr(1,:,kbbc:kebc+kb)=dahzxr(1)*hzxbcr(1,:,kbbc:kebc+kb)+...
    dbhzxr(1)*(eyzbcr(2,:,kbbc:kb+kebc)+eyxbcr(2,:,kbbc:kb+kebc)-...
    ey(ib,:,1:kb));
hzxbcr(1,:,kbbc+kb:kefbc)=dahzxr(1)*hzxbcr(1,:,kbbc+kb:kefbc)+...
    dbhzxr(1)*(eyzbcr(2,:,kbbc+kb:kefbc)+eyxbcr(2,:,kbbc+kb:kefbc)-...
         eyzbcu(ib,:,2:kebc)-eyxbcu(ib,:,2:kebc));
hzybcr(:,1:je,2:kefbc)=da(1).*hzybcr(:,1:je,2:kefbc)+...
    db(1).*(exybcr(:,2:jb,2:kefbc)+exzbcr(:,2:jb,2:kefbc)-...
    exybcr(:,1:je,2:kefbc)-exzbcr(:,1:je,2:kefbc));

% Down
hzxbcd(1:ie,1:je,2:kebc)=da(1).*hzxbcd(1:ie,1:je,2:kebc)-...
    db(1).*(eyxbcd(2:ib,1:je,2:kebc)+eyzbcd(2:ib,1:je,2:kebc)-...
                                           eyxbcd(1:ie,1:je,2:kebc)-eyzbcd(1:ie,1:je,2:kebc));
hzybcd(1:ie,1:je,2:kebc)=da(1).*hzybcd(1:ie,1:je,2:kebc)+...
    db(1).*(exybcd(1:ie,2:jb,2:kebc)+exzbcd(1:ie,2:jb,2:kebc)-...
                                           exybcd(1:ie,1:je,2:kebc)-exzbcd(1:ie,1:je,2:kebc));
% Up
hzxbcu(1:ie,1:je,2:kebc)=da(1).*hzxbcu(1:ie,1:je,2:kebc)-...
    db(1).*(eyxbcu(2:ib,1:je,2:kebc)+eyzbcu(2:ib,1:je,2:kebc)-...
                                           eyxbcu(1:ie,1:je,2:kebc)-eyzbcu(1:ie,1:je,2:kebc));
hzybcu(1:ie,1:je,2:kebc)=da(1).*hzybcu(1:ie,1:je,2:kebc)+...
    db(1).*(exybcu(1:ie,2:jb,2:kebc)+exzbcu(1:ie,2:jb,2:kebc)-...
                                           exybcu(1:ie,1:je,2:kebc)-exzbcu(1:ie,1:je,2:kebc));
%***********************************************************************
%get the SAR in the human body for each time step
%***********************************************************************
for si=iw+2:ie-iw
    for  sj=jw+2:je-jw 
        for sk=kw+2:ke-kw
           etemp=(abs(ex(si-1,sj,sk)+ex(si,sj,sk)))^2+...
               (abs(ey(si,sj-1,sk)+ey(si,sj,sk)))^2+(abs(ez(si,sj,sk-1)+ez(si,sj,sk)))^2;
           %(ex(i)+ex(i+1))/2 is linear interpolation, to get the e power
           %of the middle point. abs(E)^2 is the power(E*conj(E))
           Epower(si-iw-1,sj-jw-1, sk-kw-1)=etemp;
           
           sigpoint=sig(cz(si-iw,sj-jw,sk-1-kw))/2+sig(cz(si-iw,sj-jw,sk-kw))/2;
           denpoint=row(cz(si-iw,sj-jw,sk-1-kw))/2+row(cz(si-iw,sj-jw,sk-kw))/2;
           
            if denpoint==0
                chestSAR(si-iw-1,sj-jw-1, sk-kw-1)=0;
            else
                chestSAR(si-iw-1,sj-jw-1, sk-kw-1)=sigpoint*etemp/denpoint/2;
            end
            
        end
    end
end

%***********************************************************************
%    show the result and draw PIC
%***********************************************************************
 %get the average ()  
ty=ceil(je/2)-jw;       %the centered picture
tx=ceil(ie/2)-iw;

exzview(:,:)=chestSAR(50:size(chestSAR,1)-50, ty,20:size(chestSAR,3));
eyzview(:,:)=chestSAR(tx,:, 20:size(chestSAR,3));

timestep=int2str(n);

figure(1);
subplot('position',[0.1 0.5 0.7 0.4]),pcolor((exzview'));
shading flat;
%caxis([-4.0, 0])
colorbar;
axis image;
title([' Epower(xz plane), time step = ',timestep]);
%ylabel('y coordinate');

subplot('position',[0.1 0.05 0.7 0.35]),pcolor((eyzview'));
shading flat;
%caxis([-4.0, 0])
colorbar;
axis image;
title(['Epower(yz plane), time step = ',timestep]);
%ylabel('z coordinate');

nn=ceil(n/30);
M11(:,nn)=getframe(gcf,rect);

end % end the "if n" loop
%***********************************************************************
%     END TIME-STEPPING LOOP
%***********************************************************************                                       


end


