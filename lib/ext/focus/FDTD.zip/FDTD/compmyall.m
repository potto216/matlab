% Nov 2008 by Ruihua Ding, All rights reserved. 
% If used the following program, should mention the author and her
% associate insistution: 
% Biomedical Ultrasonics and Electromagnetics Lab. 
% Director: Prof Robert McGough, Michigan State University, Electrical Engineering
% department. 

% This program calculate the temperature 
% input : the Electric power and SAR in the simulation domain
% output: the temperature rise.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  calculate the temperature
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear
load chestSARfina3k.mat % the file has the SAR result of the human body

% the following program calculated the temperature RISE due to the RF
% applicator heating.

stepsize=1e-3;
[TEMPRISE] = bhte(1e4*chestSAR, stepsize);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  show the simulation result
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

zend=size(Etotal,3); 
xsub=50;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% show the temperature
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tem1view(:,:)=TEMPRISE(xsub+50,5:105,30:zend);   %yz plane
tem2view(:,:)=TEMPRISE(50:150,xsub+5,30:zend);  %xz plane

figure;
subplot('position',[0.1 0.5 0.7 0.4]),pcolor((tem2view'));
shading flat;
%caxis([-4.0, 0])
colorbar;
axis image;
title([' temperature(xz plane)']);
ylabel('z axis(cm)');
xlabel('x axis(cm)');

subplot('position',[0.1 0.05 0.7 0.35]),pcolor((tem1view'));
shading flat;
%caxis([-4.0, 0])
colorbar;
axis image;
%title(['temperature(yz plane)']);
ylabel('z axis(cm)');
xlabel('y axis(cm)');
clear tem1view tem2view

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% show the Efield
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tem1view(:,:)=Etotal(xsub+50,5:105,30:zend);   %yz plane
tem2view(:,:)=Etotal(50:150,xsub+5,30:zend);  %xz plane
xaxis=num2str(xsub+50);
yaxis=num2str(xsub+5);

figure;
subplot('position',[0.1 0.5 0.7 0.4]),pcolor((tem2view'));
shading flat;
colorbar;
axis image;
title([' Efield(xz plane)']);

subplot('position',[0.1 0.05 0.7 0.35]),pcolor((tem1view'));
shading flat;
colorbar;
axis image;
ylabel('z axis(cm)');
xlabel('y axis(cm)');
%title(['  x = ', xaxis]);

clear tem1view tem2view

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% show the SAR
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tem1view(:,:)=chestSAR(xsub+50,5:105,30:zend);   %yz plane
tem2view(:,:)=chestSAR(50:150,xsub+5,30:zend);  %xz plane

xaxis=num2str(xsub+50);
yaxis=num2str(xsub+5);

figure;
subplot('position',[0.1 0.5 0.7 0.4]),pcolor((tem2view'));
shading flat;
colorbar;
axis image;
ylabel('z axis(cm)');
title([' SAR(xz plane) ']);

subplot('position',[0.1 0.05 0.7 0.35]),pcolor((tem1view'));
shading flat;
%caxis([-4.0, 0])
colorbar;
axis image;
ylabel('z axis(cm)');
xlabel('y axis(cm)');

